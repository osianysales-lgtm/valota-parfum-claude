#!/bin/bash
cd "$(dirname "$0")" || exit 1
DEST="$HOME/.claude/skills/animador-zero"
if [ ! -f "animador-zero/SKILL.md" ]; then echo "Extraia o zip inteiro antes de instalar."; exit 1; fi
mkdir -p "$HOME/.claude/skills" && rm -rf "$DEST" && cp -R "animador-zero" "$DEST" || { echo "Algo deu errado ao copiar."; exit 1; }
echo "Pronto! Abra o Claude, va na aba Code, comece uma conversa nova e escreva: Instala o Animador Zero"
