@echo off
title Animador Zero - instalador
set "DEST=%USERPROFILE%\.claude\skills\animador-zero"
echo.
echo Instalando o Animador Zero em:
echo   %DEST%
echo.
if not exist "%~dp0animador-zero\SKILL.md" (
  echo Nao achei a pasta animador-zero ao lado deste arquivo.
  echo Extraia o zip inteiro antes de instalar.
  pause
  exit /b 1
)
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%~dp0animador-zero" "%DEST%\" /e /i /q /y >nul
if errorlevel 1 (
  echo Algo deu errado ao copiar. Tente de novo.
  pause
  exit /b 1
)
echo Pronto!
echo.
echo Agora abra o Claude, va na aba Code, comece uma conversa nova e escreva:
echo   Instala o Animador Zero
echo.
pause
