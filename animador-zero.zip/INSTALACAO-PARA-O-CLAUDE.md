# Instalação do Animador Zero (instruções para o Claude)

A pessoa arrastou este zip para a conversa e pediu para instalar a skill. Faça assim:

1. Extraia o zip numa pasta temporária.
2. Copie a pasta `animador-zero/` (a que tem o SKILL.md) para `~/.claude/skills/animador-zero/`
   (no Windows: `%USERPROFILE%\.claude\skills\animador-zero\`). Se já existir, substitua.
   Copie só essa pasta; os arquivos .html, .bat e .command da raiz são para a pessoa.
3. Rode `python ~/.claude/skills/animador-zero/scripts/setup.py --instalar` (no Windows, `python` ou `py`).
   Se faltar Node.js, ffmpeg, Chrome ou Python, o script mostra o comando de instalação: explique em uma frase
   o que vai ser instalado, peça o ok e rode. Rode o setup de novo até aparecer TUDO PRONTO.
4. Diga em português simples que está pronto e que o próximo passo é escolher o personagem e mandar o áudio
   da conversa (ou pedir o roteiro para gerar no ElevenLabs). Se a skill não aparecer nesta conversa,
   peça para a pessoa abrir uma conversa nova.
