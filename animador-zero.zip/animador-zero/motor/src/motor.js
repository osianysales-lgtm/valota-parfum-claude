import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { Reflector } from 'three/addons/objects/Reflector.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { drawMain, drawRival, drawAmbient, PANEL_T } from './panels.js';
import ROTEIRO from '/projeto/roteiro.js';
import { TW as QTW, TH as QTH } from './cartoes.js';
import { BokehPass } from 'three/addons/postprocessing/BokehPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { Pass, FullScreenQuad } from 'three/addons/postprocessing/Pass.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
const QV = { blender: ROTEIRO };

const W = 1080, H = 1920, FPS = 30;
const DURATION = 44.0;
window.DURATION = DURATION;

// ---------- helpers ----------
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, k) => a + (b - a) * k;
const smooth = (a, b, x) => { const k = clamp((x - a) / (b - a)); return k * k * (3 - 2 * k); };
const win = (t, a, b, f = 0.22) => smooth(a - f * 0.3, a + f * 0.7, t) * (1 - smooth(b - f * 0.3, b + f * 0.7, t));
const back = x => { x = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
function mulberry32(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const rnd = mulberry32(11);
const blink = (t, ph) => { const p = (t + ph) % 3.3; return p < 0.13 ? 0.12 : 1; };

// ---------- subtitles ----------
const SUBS = [];
const HERO_TALK = [[0, 2.5], [2.6, 5.12], [6.4, 7.85], [7.95, 10.85], [10.95, 12.92], [14.5, 17.3], [17.35, 18.46], [22.95, 23.55], [30.1, 32.56], [33.65, 35.72], [37.75, 39.88], [40.25, 42.6]];
const subEl = document.getElementById('sub');
const style = document.createElement('style');
style.textContent = '#sub b{color:#ffd166;font-weight:800} #sub.c b{color:#fff}';
document.head.appendChild(style);

// ---------- renderer ----------
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(1);
renderer.setSize(W, H, false);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.06;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
{
  const gl = renderer.getContext();
  const ext = gl.getExtension('WEBGL_debug_renderer_info');
  window.gpuInfo = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : 'unknown';
}

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x06050e);
scene.fog = new THREE.FogExp2(0x0b0820, 0.011);
const camera = new THREE.PerspectiveCamera(35, W / H, 0.1, 400);
scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.2;

const rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, samples: 4 });
const composer = new EffectComposer(renderer, rt);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(W, H), 0.42, 0.6, 0.82);
composer.addPass(bloom);
composer.addPass(new OutputPass());

// ---------- materials ----------
const mat = (color, o = {}) => new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: 0.88, metalness: 0, ...o });
const glow = (color, o = {}) => new THREE.MeshBasicMaterial({ color, toneMapped: false, ...o });
function mesh(geo, m, x = 0, y = 0, z = 0, parent) { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = true; if (parent) parent.add(o); return o; }

// ---------- backdrop ----------
{
  // stars
  for (const [n, size, op] of [[1500, 2.2, 0.75], [260, 3.6, 0.95]]) {
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { pos[i * 3] = (rnd() - 0.5) * 150; pos[i * 3 + 1] = -45 + rnd() * 100; pos[i * 3 + 2] = -70 - rnd() * 60; }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const p = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xdcd6ff, size, sizeAttenuation: false, transparent: true, opacity: op, fog: false, depthWrite: false }));
    scene.add(p);
  }
  // planet
  const pl = new THREE.Mesh(new THREE.IcosahedronGeometry(7, 2), new THREE.MeshStandardMaterial({ color: 0x4a2f8f, flatShading: true, roughness: 1, fog: false, emissive: 0x1a0c40, emissiveIntensity: 0.6 }));
  pl.position.set(-17, 26, -110); scene.add(pl);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(11, 0.35, 4, 48), new THREE.MeshBasicMaterial({ color: 0x8a66d8, fog: false, transparent: true, opacity: 0.55 }));
  ring.position.copy(pl.position); ring.rotation.set(1.25, 0.2, 0.3); scene.add(ring);
  // horizon glow
  const c = document.createElement('canvas'); c.width = 8; c.height = 256; const x = c.getContext('2d');
  const gr = x.createLinearGradient(0, 0, 0, 256);
  gr.addColorStop(0, 'rgba(60,20,120,0)'); gr.addColorStop(0.45, 'rgba(150,40,160,0.35)'); gr.addColorStop(0.62, 'rgba(255,90,150,0.75)'); gr.addColorStop(0.7, 'rgba(255,150,90,0.55)'); gr.addColorStop(0.8, 'rgba(60,20,90,0.15)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = gr; x.fillRect(0, 0, 8, 256);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const hz = new THREE.Mesh(new THREE.PlaneGeometry(320, 46), new THREE.MeshBasicMaterial({ map: tex, transparent: true, fog: false, depthWrite: false, opacity: 0.5 }));
  hz.position.set(0, 1.5, -100); scene.add(hz);
}

// city skyline
const cityMats = [];
{
  const palette = ['#ff5fb0', '#63e6ff', '#ffc36b', '#a98bff', '#ff8a5c'];
  for (let k = 0; k < 4; k++) {
    const c = document.createElement('canvas'); c.width = 96; c.height = 256; const x = c.getContext('2d');
    x.fillStyle = '#0a0916'; x.fillRect(0, 0, 96, 256);
    const col = palette[k % palette.length];
    for (let r = 0; r < 26; r++) for (let q = 0; q < 8; q++) {
      if (rnd() < 0.5) { x.fillStyle = rnd() < 0.75 ? col : palette[Math.floor(rnd() * palette.length)]; x.globalAlpha = 0.55 + rnd() * 0.45; x.fillRect(6 + q * 11, 6 + r * 9.6, 7, 5); }
    }
    x.globalAlpha = 1;
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.magFilter = THREE.NearestFilter;
    cityMats.push(new THREE.MeshBasicMaterial({ map: tex }));
  }
  const neon = [glow(0xff4fa8), glow(0x5fe0ff), glow(0xa98bff)];
  for (let i = 0; i < 46; i++) {
    const w = 4 + rnd() * 6, h = 6 + rnd() * 11, d = 4 + rnd() * 5;
    const tx = (rnd() - 0.5) * 190, tz = -85 - rnd() * 40;
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), cityMats[i % 4]);
    b.position.set(tx, -9 + h / 2, tz); scene.add(b);
    if (rnd() < 0.55) { const s = new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, 0.14, d + 0.1), neon[i % 3]); s.position.set(tx, -9 + h + 0.07, tz); scene.add(s); }
    if (rnd() < 0.25) { const a = new THREE.Mesh(new THREE.BoxGeometry(0.1, 3, 0.1), neon[(i + 1) % 3]); a.position.set(tx, -9 + h + 1.5, tz); scene.add(a); }
  }
}

// platform
{
  const slab = new THREE.Mesh(new THREE.BoxGeometry(70, 0.3, 10.7), new THREE.MeshStandardMaterial({ color: 0x0e0c1f, roughness: 0.8, metalness: 0.1 }));
  slab.position.set(0, -0.165, -2.15); slab.receiveShadow = true; scene.add(slab);
  const edge = new THREE.Mesh(new THREE.BoxGeometry(70, 0.05, 0.05), glow(0x9a7cff)); edge.position.set(0, -0.01, 3.2); scene.add(edge);
  const edge2 = new THREE.Mesh(new THREE.BoxGeometry(70, 0.02, 0.02), glow(0x5a3fd0)); edge2.position.set(0, -0.3, 3.2); scene.add(edge2);
  const mirror = new Reflector(new THREE.PlaneGeometry(70, 10.7), { textureWidth: 540, textureHeight: 960, color: 0x8f88b8, clipBias: 0.003 });
  mirror.rotation.x = -Math.PI / 2; mirror.position.set(0, 0, -2.15); scene.add(mirror);
  const sheen = new THREE.Mesh(new THREE.PlaneGeometry(70, 10.7), new THREE.MeshStandardMaterial({ color: 0x0b0919, roughness: 0.62, metalness: 0, transparent: true, opacity: 0.36, depthWrite: false, envMapIntensity: 0.3 }));
  sheen.rotation.x = -Math.PI / 2; sheen.position.set(0, 0.004, -2.15); sheen.receiveShadow = true; scene.add(sheen);
}

// lights
scene.add(new THREE.HemisphereLight(0x7a6cff, 0x0a0614, 0.4));
const key = new THREE.DirectionalLight(0xffeef6, 1.55); key.position.set(-3.5, 5.5, 6.5); key.castShadow = true;
key.shadow.mapSize.set(2048, 2048); Object.assign(key.shadow.camera, { left: -5, right: 5, top: 5, bottom: -2, near: 1, far: 20 }); key.shadow.bias = -0.0004; key.shadow.radius = 5;
scene.add(key);
const rim = new THREE.DirectionalLight(0xff3fa4, 3.0); rim.position.set(4, 3.5, -6); scene.add(rim);
const rim2 = new THREE.DirectionalLight(0x4fd8ff, 1.9); rim2.position.set(-5, 3, -5); scene.add(rim2);
const panelLight = new THREE.PointLight(0x7fd6ff, 5, 9, 1.5); panelLight.position.set(0.05, 2.9, -0.45); scene.add(panelLight);
const spot = new THREE.SpotLight(0xd6c8ff, 20, 15, 0.42, 0.8, 1.4); spot.position.set(0.05, 7.5, 2.8); spot.target.position.set(0.05, 0.7, 0); scene.add(spot, spot.target);
const PANEL_COL = [0x5fe0ff, 0xff4fa8, 0x5fe0ff, 0xffc24a, 0xff8a5c, 0xff8a5c, 0xff8a5c, 0xff4fa8, 0xffc24a, 0xff4fa8];
const edgeLight = new THREE.PointLight(0x8a6cff, 3.5, 5, 1.8); edgeLight.position.set(0, 0.25, 1.9); scene.add(edgeLight);
const coldLight = new THREE.PointLight(0x4a78ff, 0, 5, 1.6); coldLight.position.set(-1.7, 2.1, 0.8); scene.add(coldLight);

// ---------- characters ----------
function buildKid(o) {
  const g = new THREE.Group();
  const skin = mat(o.skin), hood = mat(o.hood), hoodD = mat(o.hoodD), pants = mat(o.pants), hair = mat(o.hair);
  const shoe = mat(0xd9d5ee, { emissive: 0x8a7cff, emissiveIntensity: 0.04 });
  mesh(new THREE.BoxGeometry(0.2, 0.52, 0.22), pants, -0.14, 0.38, 0, g);
  mesh(new THREE.BoxGeometry(0.2, 0.52, 0.22), pants, 0.14, 0.38, 0, g);
  mesh(new THREE.BoxGeometry(0.25, 0.14, 0.38), shoe, -0.14, 0.07, 0.06, g);
  mesh(new THREE.BoxGeometry(0.25, 0.14, 0.38), shoe, 0.14, 0.07, 0.06, g);
  const body = new THREE.Group(); body.position.y = 0.62; g.add(body);
  const torso = mesh(new THREE.CylinderGeometry(0.27, 0.35, 0.64, 7), hood, 0, 0.32, 0, body); torso.scale.z = 0.76;
  mesh(new THREE.BoxGeometry(0.32, 0.13, 0.03), hoodD, 0, 0.14, 0.255, body);
  mesh(new THREE.BoxGeometry(0.022, 0.17, 0.022), mat(o.string), -0.06, 0.47, 0.215, body);
  mesh(new THREE.BoxGeometry(0.022, 0.17, 0.022), mat(o.string), 0.06, 0.47, 0.215, body);
  const hb = mesh(new THREE.IcosahedronGeometry(0.24, 0), hoodD, 0, 0.63, -0.13, body); hb.scale.set(1.35, 0.7, 1);
  const arms = [];
  for (const s of [-1, 1]) {
    const a = new THREE.Group(); a.position.set(s * 0.36, 0.56, 0); body.add(a);
    mesh(new THREE.BoxGeometry(0.15, 0.46, 0.16), hood, 0, -0.23, 0, a);
    mesh(new THREE.IcosahedronGeometry(0.085, 0), skin, 0, -0.51, 0, a);
    arms.push(a);
  }
  const head = new THREE.Group(); head.position.set(0, 0.68, 0.02); body.add(head);
  const skull = mesh(new THREE.IcosahedronGeometry(0.42, 1), skin, 0, 0.38, 0, head); skull.scale.set(1, 0.95, 0.95);
  mesh(new THREE.IcosahedronGeometry(0.08, 0), skin, -0.4, 0.36, 0, head);
  mesh(new THREE.IcosahedronGeometry(0.08, 0), skin, 0.4, 0.36, 0, head);
  const cap = mesh(new THREE.IcosahedronGeometry(0.455, 1), hair, 0, 0.5, -0.05, head); cap.scale.set(1.03, 0.76, 1.03);
  for (let i = 0; i < 5; i++) {
    const f = mesh(new THREE.ConeGeometry(0.11, 0.24, 4), hair, -0.26 + i * 0.13, 0.6 - Math.abs(i - 2) * 0.012, 0.33 - Math.abs(i - 2) * 0.03, head);
    f.rotation.set(Math.PI + 0.35, 0.4 * (i - 2) * 0.3, o.messy ? (i % 2 ? 0.25 : -0.3) : 0.12 * (i - 2));
  }
  const eyes = [], brows = [];
  const eyeM = new THREE.MeshBasicMaterial({ color: 0x1a1220 }), hiM = new THREE.MeshBasicMaterial({ color: 0xc8c8d2 });
  for (const s of [-1, 1]) {
    const e = new THREE.Group(); e.position.set(s * 0.15, 0.36, 0.378); head.add(e);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), eyeM); ball.scale.set(1, 1.3, 0.45); e.add(ball);
    const hi = new THREE.Mesh(new THREE.SphereGeometry(0.015, 6, 6), hiM); hi.position.set(0.016, 0.03, 0.024); e.add(hi);
    eyes.push(e);
    const b = mesh(new THREE.BoxGeometry(0.15, 0.032, 0.03), hair, s * 0.15, 0.49, 0.385, head); b.castShadow = false; brows.push(b);
  }
  if (o.bags) for (const s of [-1, 1]) { const bg = mesh(new THREE.BoxGeometry(0.12, 0.02, 0.02), mat(0xb98a86), s * 0.15, 0.275, 0.392, head); bg.castShadow = false; }
  const nose = mesh(new THREE.ConeGeometry(0.035, 0.08, 4), mat(o.nose), 0, 0.3, 0.42, head); nose.rotation.x = Math.PI / 2;
  const mouthM = new THREE.MeshBasicMaterial({ color: 0x4a1826, side: THREE.DoubleSide });
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.062, 0.013, 4, 12, Math.PI), mouthM); mouth.rotation.z = Math.PI; mouth.position.set(0, 0.22, 0.4); head.add(mouth);
  const openM = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), mouthM); openM.position.set(0, 0.2, 0.39); openM.scale.set(1, 0.01, 0.4); head.add(openM);
  if (o.headset) {
    const dk = mat(0x15131f, { roughness: 0.5 });
    const band = mesh(new THREE.TorusGeometry(0.47, 0.03, 6, 18, Math.PI), dk, 0, 0.4, -0.02, head);
    for (const s of [-1, 1]) {
      const cup = mesh(new THREE.CylinderGeometry(0.115, 0.115, 0.09, 10), dk, s * 0.47, 0.38, -0.02, head); cup.rotation.z = Math.PI / 2;
      const rg = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.014, 6, 16), glow(0x5fe0ff)); rg.position.set(s * 0.52, 0.38, -0.02); rg.rotation.y = Math.PI / 2; head.add(rg);
    }
    const mic = mesh(new THREE.BoxGeometry(0.02, 0.02, 0.32), dk, -0.45, 0.24, 0.16, head); mic.rotation.y = -0.35;
    mesh(new THREE.SphereGeometry(0.03, 8, 6), dk, -0.39, 0.24, 0.32, head);
  }
  return { g, body, head, armL: arms[0], armR: arms[1], eyes, brows, mouth, openM };
}
function poseKid(c, P, t, ph) {
  c.g.position.set(P.x, P.hop, P.z ?? 0); c.g.rotation.y = P.yaw;
  c.body.rotation.x = P.lean;
  c.head.rotation.set(P.hp, P.hy, P.hr);
  c.armL.rotation.set(P.aLx, 0, P.aLz); c.armR.rotation.set(P.aRx, 0, P.aRz);
  const bl = blink(t, ph);
  for (let i = 0; i < 2; i++) {
    c.eyes[i].scale.set(1, Math.max(0.1, P.eye * bl), 1);
    c.brows[i].position.y = 0.49 + P.brow; c.brows[i].rotation.z = (i ? -1 : 1) * P.browT;
  }
  const m = P.mouth; c.mouth.scale.set(1, Math.sign(m || 1) * Math.max(0.18, Math.abs(m)), 1);
  c.mouth.visible = P.open < 0.25; c.openM.visible = P.open >= 0.25; c.openM.scale.set(0.9, Math.max(0.01, P.open), 0.4);
}

const hero = buildKid({ skin: 0xf3bea6, nose: 0xe2a48e, hood: 0x1fa79c, hoodD: 0x178178, pants: 0x242a4c, hair: 0x2b1b22, string: 0xffffff, headset: true });
const rival = buildKid({ skin: 0xd9b3ad, nose: 0xc59b96, hood: 0x66739f, hoodD: 0x4d5880, pants: 0x1d2138, hair: 0x40342f, string: 0x9aa3c4, messy: true, bags: true, shoeGlow: 0.1 });
scene.add(hero.g, rival.g);

function buildBot() {
  const g = new THREE.Group();
  const gc = document.createElement('canvas'); gc.width = gc.height = 128; const gx = gc.getContext('2d');
  const gg = gx.createRadialGradient(64, 64, 4, 64, 64, 86); gg.addColorStop(0, '#ffffff'); gg.addColorStop(0.5, '#9a9a9a'); gg.addColorStop(1, '#1c1c1c'); gx.fillStyle = gg; gx.fillRect(0, 0, 128, 128);
  const glowTex = new THREE.CanvasTexture(gc); glowTex.colorSpace = THREE.SRGBColorSpace;
  const coral = new THREE.MeshPhysicalMaterial({ color: 0xea744b, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.16, emissive: 0xff5a1c, emissiveMap: glowTex, emissiveIntensity: 0.6, envMapIntensity: 0.7 });
  const coralD = new THREE.MeshPhysicalMaterial({ color: 0xc9562f, roughness: 0.35, clearcoat: 0.8, clearcoatRoughness: 0.2, emissive: 0xff6a30, emissiveIntensity: 0.2 });
  const inner = new THREE.PointLight(0xff7a40, 3, 4.5, 1.6); g.add(inner);
  const body = mesh(new RoundedBoxGeometry(0.86, 0.74, 0.7, 4, 0.16), coral, 0, 0, 0, g);
  mesh(new RoundedBoxGeometry(0.62, 0.4, 0.06, 3, 0.03), new THREE.MeshStandardMaterial({ color: 0x24121c, roughness: 0.3 }), 0, 0.03, 0.335, g);
  const eyeM = glow(0xfff0dc);
  const eyeL = new THREE.Mesh(new RoundedBoxGeometry(0.1, 0.19, 0.03, 2, 0.015), eyeM); eyeL.position.set(-0.15, 0.04, 0.375); g.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.15; g.add(eyeR);
  mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.24, 6), coralD, 0, 0.48, 0, g);
  const bulbM = glow(0xffe2c2); const bulb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.06, 1), bulbM); bulb.position.set(0, 0.63, 0); g.add(bulb);
  mesh(new RoundedBoxGeometry(0.12, 0.28, 0.32, 2, 0.05), coralD, -0.49, -0.05, 0, g);
  mesh(new RoundedBoxGeometry(0.12, 0.28, 0.32, 2, 0.05), coralD, 0.49, -0.05, 0, g);
  mesh(new THREE.CylinderGeometry(0.2, 0.27, 0.1, 12), new THREE.MeshStandardMaterial({ color: 0x2a1a22, roughness: 0.5 }), 0, -0.42, 0, g);
  const thr = new THREE.Mesh(new THREE.CircleGeometry(0.19, 20), glow(0xffb48c)); thr.rotation.x = Math.PI / 2; thr.position.y = -0.475; g.add(thr);
  const tl = new THREE.PointLight(0xff9460, 2.2, 2.2, 1.8); tl.position.y = -0.6; g.add(tl);
  const rings = [];
  for (let i = 0; i < 3; i++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.006, 6, 48), glow(0xffe2c2, { transparent: true, opacity: 0, depthWrite: false })); r.position.z = 0.1; g.add(r); rings.push(r); }
  return { g, body, eyeL, eyeR, bulb, bulbM, rings, thr, coral, coralD, inner };
}
const bot = buildBot(); scene.add(bot.g);
const halo = (() => { const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
  const g = x.createRadialGradient(128, 128, 0, 128, 128, 128); g.addColorStop(0, 'rgba(255,170,110,0.6)'); g.addColorStop(0.4, 'rgba(255,120,70,0.2)'); g.addColorStop(1, 'rgba(255,90,50,0)'); x.fillStyle = g; x.fillRect(0, 0, 256, 256);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, toneMapped: false, fog: false }));
  sp.scale.set(2.0, 2.0, 1); scene.add(sp); return sp; })();

// divider beam
const divider = new THREE.Group(); divider.position.set(-1.02, 0, 0.3); scene.add(divider);
{ const g1 = new THREE.BoxGeometry(0.035, 1, 0.035); g1.translate(0, 0.5, 0); divider.add(new THREE.Mesh(g1, glow(0xd9ccff)));
  const fl = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.012, 3.2), glow(0xb9a4ff)); fl.position.set(0, 0.006, -0.4); divider.add(fl); divider.userData.fl = fl; divider.userData.beam = divider.children[0]; }

// ---------- holo panels ----------
function makePanel(wPx, hPx, wWorld) {
  const c = document.createElement('canvas'); c.width = wPx; c.height = hPx;
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const m = new THREE.MeshBasicMaterial({ map: tex, transparent: true, toneMapped: false, depthWrite: false, fog: false });
  const p = new THREE.Mesh(new THREE.PlaneGeometry(wWorld, wWorld * hPx / wPx), m);
  return { c, ctx: c.getContext('2d'), tex, m, p };
}
const mainP = makePanel(1000, 700, 2.55); mainP.p.position.set(0.05, 2.74, -1.6); mainP.m.color.setScalar(0.82); scene.add(mainP.p);
const rivalP = makePanel(600, 420, 1.45); rivalP.p.position.set(-2.0, 2.78, -1.25); rivalP.p.rotation.y = 0.16; scene.add(rivalP.p);
const ambient = [];
for (const [x, y, z, ry, w] of [[-2.3, 3.5, -3.4, 0.3, 1.5], [2.35, 3.3, -3.6, -0.3, 1.6], [2.2, 1.55, -3.2, -0.25, 1.3], [-2.45, 1.45, -3.5, 0.28, 1.3], [0.4, 4.35, -3.8, 0, 1.7]]) {
  const a = makePanel(512, 360, w); a.p.position.set(x, y, z); a.p.rotation.y = ry; a.m.opacity = 0.34; scene.add(a.p); ambient.push(a);
}

// ---------- camera shots ----------
const SH = {
  W2: { p: [0.05, 1.5, 9.4], q: [0.05, 0.95, 0], push: 0.05 },
  M2: { p: [0.05, 1.45, 7.5], q: [0.05, 1.2, 0], push: 0.05 },
  CH: { p: [-0.18, 1.55, 4.3], q: [-0.45, 1.2, 0], push: 0.06 },
  CB: { p: [0.86, 1.35, 4.0], q: [0.57, 0.82, 0], push: 0.07 },
  WS: { p: [-0.72, 1.6, 11.6], q: [-0.72, 1.3, 0], push: 0.04 },
  CR: { p: [-1.42, 1.45, 5.4], q: [-1.7, 1.5, 0], push: 0.06 },
  PF: { p: [0.05, 1.93, 9.0], q: [0.05, 1.93, 0], push: 0.035 },
  PF2: { p: [-1.05, 2.0, 8.75], q: [0.2, 1.95, -0.2], push: 0.035 },
  W2o: { p: [0.05, 1.5, 9.0], q: [0.05, 0.95, 0], push: -0.08 },
};
const CUTS = [[0, 'W2'], [2.58, 'CH'], [5.35, 'CB'], [6.38, 'CH'], [7.9, 'PF'], [10.9, 'CH'], [13.05, 'CB'], [14.45, 'W2'], [17.3, 'CH'], [18.58, 'CB'], [19.8, 'M2'], [21.55, 'CB'], [22.9, 'CH'], [23.6, 'PF2'], [26.7, 'PF'], [28.8, 'M2'], [30.05, 'PF2'], [33.6, 'M2'], [35.75, 'W2o'], [37.7, 'M2'], [40.2, 'PF'], [DURATION, 'END']];
const vp = new THREE.Vector3(), vq = new THREE.Vector3();
function setCamera(t) {
  let i = 0; while (i < CUTS.length - 2 && t >= CUTS[i + 1][0]) i++;
  const s = SH[CUTS[i][1]], k = clamp((t - CUTS[i][0]) / (CUTS[i + 1][0] - CUTS[i][0]));
  vp.set(...s.p); vq.set(...s.q);
  vp.lerp(vq, s.push * k);
  vp.x += Math.sin(t * 0.55) * 0.03; vp.y += Math.sin(t * 0.41 + 1.3) * 0.02;
  camera.position.copy(vp); camera.lookAt(vq);
}

// ---------- acting ----------
function heroPose(t) {
  const P = { x: -0.45, hop: 0, yaw: 0.22, lean: 0, hp: 0, hy: 0, hr: 0, aLx: 0, aLz: -0.1, aRx: 0, aRz: 0.1, eye: 1, brow: 0, browT: 0, mouth: 0.6, open: 0 };
  let w;
  const run = 1 - smooth(0, 0.85, t); P.x -= 1.9 * run; P.hop += 0.07 * run * Math.abs(Math.sin(t * 14));
  w = win(t, -1, 2.5); P.hy += 0.45 * w; P.aLz -= 0.5 * w; P.aRz += 0.5 * w; P.eye += 0.15 * w; P.brow += 0.03 * w; P.hop += 0.04 * w * Math.abs(Math.sin(t * 8));
  w = win(t, 2.58, 5.3); P.hy -= 0.15 * w; P.hp -= 0.12 * w; P.eye += 0.2 * w; P.brow += 0.04 * w; P.mouth += 0.4 * w;
  const pump = win(t, 3.4, 4.9, 0.3); P.aRx -= 2.3 * pump; P.aRz += 0.25 * pump; P.hop += 0.05 * pump * Math.abs(Math.sin((t - 3.4) * 8));
  w = win(t, 5.35, 6.35); P.hy += 0.5 * w; P.brow += 0.03 * w; P.hr += 0.08 * w;
  w = win(t, 6.38, 7.05, 0.12); P.hy += w * 0.32 * Math.sin((t - 6.38) * 15);
  const chop = win(t, 6.95, 7.75, 0.15); P.aRx -= chop * (1.3 + 0.35 * Math.sin((t - 6.95) * 16)); P.hy += 0.3 * win(t, 6.38, 7.85); P.browT -= 0.1 * chop; P.mouth += 0.3 * chop;
  w = win(t, 7.9, 10.85); P.hp -= 0.3 * w; P.aLz -= 0.9 * w; P.aRz += 0.9 * w; P.hop += 0.04 * w * Math.abs(Math.sin(t * 7)); P.eye += 0.12 * w;
  w = win(t, 10.9, 13.0); P.hy += 0.25 * w; P.mouth += 0.4 * w; const one = win(t, 11.9, 12.9, 0.2); P.aRx -= 2.75 * one; P.aRz += 0.25 * one; P.brow += 0.03 * one;
  w = win(t, 13.05, 14.4); P.hy += 0.5 * w; P.hr -= 0.06 * w; P.mouth -= 0.3 * w;
  w = win(t, 14.45, 16.15); P.hp -= 0.25 * w; P.aLx -= 2.6 * w; P.aLz -= 0.3 * w; P.browT += 0.1 * w; P.mouth -= 0.5 * w;
  w = win(t, 16.15, 19.8, 0.35); P.lean += 0.2 * w; P.hp += 0.3 * w; P.eye -= 0.45 * w; P.browT += 0.2 * w; P.mouth -= 1.3 * w;
  w = win(t, 19.8, 22.85, 0.4); P.hy += 0.5 * w; P.eye -= 0.1 * w; P.mouth -= 0.2 * w;
  w = win(t, 22.9, 23.6, 0.1); P.hy += 0.55 * w; P.hp -= 0.12 * w; P.eye += 0.4 * w; P.brow += 0.06 * w;
  w = win(t, 23.6, 28.8); P.hp -= 0.3 * w; P.eye += 0.15 * w;
  for (const tt of [24.0, 25.0, 26.0]) P.hp += 0.1 * win(t, tt, tt + 0.3, 0.2);
  w = win(t, 28.8, 30.0); P.hy += 0.35 * w; P.mouth += 0.5 * w; const th = win(t, 29.4, 30.0, 0.15); P.aRx -= 2.7 * th; P.hp += 0.12 * th * Math.sin((t - 29.4) * 10);
  w = win(t, 30.05, 32.6); P.hy += 0.4 * w; P.aRx -= 2.2 * w; P.aRz += 0.3 * w; P.brow += 0.03 * w;
  for (const tt of [30.39, 31.15, 31.97]) { const b = win(t, tt, tt + 0.25, 0.12); P.aRx -= 0.45 * b; P.hp += 0.06 * b; }
  w = win(t, 32.6, 33.55); P.hy += 0.45 * w; P.eye += 0.3 * w; P.brow += 0.05 * w; P.open += 0.4 * w;
  w = win(t, 33.6, 35.75, 0.18); P.aLz -= 2.5 * w; P.aRz += 2.5 * w; P.hop += 0.1 * w * Math.abs(Math.sin((t - 33.6) * 8)); P.mouth += 0.6 * w; P.eye += 0.12 * w; P.hy += 0.3 * w;
  w = win(t, 35.75, 37.65); P.hy += 0.4 * w; P.mouth += 0.5 * w; P.hp -= 0.08 * w;
  w = smooth(37.6, 37.95, t); P.yaw -= 0.22 * w;
  w = win(t, 37.7, 40.15); P.aRx -= 2.75 * w; P.aRz += 0.35 * w; P.brow += 0.03 * w;
  w = smooth(40.15, 40.45, t); const bob = Math.sin((t - 40.15) * 6.5);
  P.aLx -= w * (0.95 + 0.12 * bob); P.aRx -= w * (0.95 + 0.12 * bob); P.aLz += 0.2 * w; P.aRz -= 0.2 * w; P.hp += w * (0.1 + 0.06 * bob); P.mouth += 0.5 * w; P.eye += 0.08 * w;
  return P;
}
function rivalPose(t) {
  const P = { x: -1.6, hop: 0, yaw: 0.18, lean: 0.14, hp: 0.13, hy: 0.1, hr: 0.07, aLx: 0, aLz: -0.08, aRx: -1.15, aRz: 0.15 + 0.22 * Math.sin(t * 2.3), eye: 0.5, brow: -0.01, browT: -0.22, mouth: -0.8, open: 0 };
  P.hp += 0.05 * Math.sin(t * 1.1);
  const w = win(t, 39.7, 41.0, 0.2); P.hy += 0.7 * w; P.hp -= 0.3 * w; P.eye += 0.6 * w; P.open += 0.5 * w; P.lean -= 0.12 * w;
  return P;
}
function poseBot(t, env) {
  let x = 0.55, y = 1.1 + 0.05 * Math.sin(t * 1.9), yaw = -0.32, pitch = 0, roll = 0.04 * Math.sin(t * 1.3), eL = 1, eR = 1, ringAmp = 0, ringDir = 1, w;
  yaw += 0.6 * (1 - smooth(0.3, 1.7, t));
  const talk = (a, b) => win(t, a, b, 0.2);
  const speak = clamp(talk(5.35, 6.3) + talk(13.05, 14.35) + talk(18.58, 22.75) + talk(23.6, 30.0) + talk(32.65, 33.5) + talk(35.75, 37.65));
  x -= 0.1 * speak; roll += 0.1 * speak; eL *= 1 - 0.22 * speak; eR *= 1 - 0.22 * speak; yaw -= 0.12 * speak;
  ringAmp = Math.max(ringAmp, 0.45 * speak * Math.min(1, env * 2.4));
  w = clamp(talk(5.35, 6.3) + talk(13.05, 14.35)); roll += 0.1 * w; eL *= 1 + 0.3 * w; eR *= 1 - 0.15 * w;
  w = win(t, 7.9, 10.85); pitch -= 0.2 * w; yaw += 0.3 * w;
  w = win(t, 14.45, 17.3); pitch -= 0.2 * w; yaw += 0.3 * w;
  y += 0.12 * win(t, 19.8, 20.3, 0.15);
  w = win(t, 21.55, 22.8, 0.2); eL *= 1 - 0.75 * w; eR *= 1 - 0.75 * w; ringAmp = Math.max(ringAmp, w); if (w > 0.01) ringDir = -1;
  w = win(t, 23.6, 28.8); pitch -= 0.12 * w; yaw += 0.22 * w;
  for (const tt of [24.0, 25.0, 26.0]) { const h = win(t, tt, tt + 0.28, 0.14); y += 0.1 * h; ringAmp = Math.max(ringAmp, 0.6 * h); }
  for (const tt of [32.75, 32.95, 33.15]) ringAmp = Math.max(ringAmp, 0.6 * win(t, tt, tt + 0.3, 0.12));
  { const k = clamp((t - 32.7) / 0.6); if (k > 0 && k < 1) yaw += Math.PI * 2 * (k * k * (3 - 2 * k)); }
  w = win(t, 32.65, 33.55); eL *= 1 - 0.5 * w; eR *= 1 - 0.5 * w;
  w = win(t, 35.75, 37.65); eL *= 1 - 0.55 * w; eR *= 1 - 0.55 * w;
  w = smooth(37.6, 37.95, t); yaw += 0.32 * w;
  w = smooth(40.15, 40.45, t); y += 0.06 * w * Math.sin((t - 40.15) * 6.5); eL *= 1 - 0.6 * w; eR *= 1 - 0.6 * w;
  const bl = blink(t, 1.4);
  bot.g.position.set(x, y, 0); bot.g.rotation.set(pitch, yaw, roll);
  bot.eyeL.scale.y = Math.max(0.1, eL * bl); bot.eyeR.scale.y = Math.max(0.1, eR * bl);
  bot.bulbM.color.setScalar(1).multiply(new THREE.Color(0xffe2c2)).multiplyScalar(0.7 + 0.9 * env);
  bot.thr.scale.setScalar(0.9 + 0.15 * Math.sin(t * 9));
  const breath = 0.5 + 0.16 * Math.sin(t * 1.7) + 0.45 * ringAmp + 0.2 * env;
  bot.coral.emissiveIntensity = breath; bot.coralD.emissiveIntensity = 0.12 + breath * 0.35; bot.inner.intensity = 1.2 + 2.4 * breath;
  halo.position.set(x, y, -0.05); halo.material.opacity = 0.16 + 0.3 * breath;
  for (let i = 0; i < 3; i++) {
    let ph = (t * 0.9 + i / 3) % 1; if (ringDir < 0) ph = 1 - ph;
    const s = 0.75 + ph * 0.95; bot.rings[i].scale.set(s, s, 1);
    bot.rings[i].material.opacity = ringAmp * Math.sin(Math.PI * ph) * 0.42;
    bot.rings[i].quaternion.copy(bot.g.quaternion).invert().multiply(camera.quaternion);
  }
}

// ---------- frame ----------
let ENV = [];
const envAt = t => { const i = clamp(Math.floor(t * FPS), 0, ENV.length - 1); return ENV.length ? (ENV[i] + (ENV[Math.max(0, i - 1)] || 0)) / 2 : 0; };

window.renderFrame = (t) => {
  const env = envAt(t);
  setCamera(t);
  const HP = heroPose(t);
  if (HERO_TALK.some(([a, b]) => t >= a && t < b) && env > 0.1) HP.open = Math.max(HP.open, Math.min(1, 0.08 + env * 1.15));
  poseKid(hero, HP, t, 0.3);
  const showRival = false;
  rival.g.visible = showRival; rivalP.p.visible = showRival; divider.visible = showRival && !(t >= 16.42 && t < 20.66); coldLight.intensity = showRival ? 3 : 0;
  if (showRival) {
    poseKid(rival, rivalPose(t), t, 1.9);
    const g = t < 30 ? back((t - 14.62) / 0.55) : 1;
    divider.userData.beam.scale.y = 3.4 * Math.max(0.001, g); divider.userData.fl.scale.z = Math.max(0.001, clamp((t < 30 ? (t - 14.62) / 0.4 : 1)));
    drawRival(rivalP.ctx, t); rivalP.tex.needsUpdate = true;
    rivalP.p.position.y = 2.78 + 0.03 * Math.sin(t * 1.4);
  }
  poseBot(t, env);
  // main panel
  let pt = 0; for (const x of PANEL_T) if (t >= x) pt = x;
  const k = pt === 0 ? 1 : (t - pt) / 0.42, sc = 0.84 + 0.16 * back(k);
  mainP.p.scale.set(sc, sc, 1); mainP.m.opacity = pt === 0 ? 1 : smooth(0, 0.16, t - pt);
  const inPF = (t >= 7.9 && t < 10.9) || (t >= 23.6 && t < 28.8) || (t >= 30.05 && t < 33.6) || t >= 40.2; const inWS = false; const ps = inPF ? 1.29 : 1; mainP.p.scale.set(sc * ps, sc * ps, 1); mainP.p.position.y = (inPF ? 3.45 : inWS ? 3.25 : 3.05) + 0.035 * Math.sin(t * 1.2);
  mainP.p.rotation.y = 0.03 * Math.sin(t * 0.7);
  drawMain(mainP.ctx, t); mainP.tex.needsUpdate = true;
  panelLight.intensity = 4.2 + 2.5 * smooth(0, 0.3, t - pt) * (1 - smooth(0.3, 0.9, t - pt)); panelLight.color.setHex(PANEL_COL[Math.max(0, PANEL_T.indexOf(pt))]);
  ambient.forEach((a, i) => { a.p.position.y += 0; a.m.opacity = 0.26 + 0.08 * Math.sin(t * 0.9 + i * 1.7); });
  // city lights
  const ck = 0.75 + 0.6 * smooth(7.95, 9.2, t) * (1 - smooth(12.9, 14.4, t)) - 0.5 * smooth(35.75, 37.2, t) * (1 - smooth(39.5, 40.2, t));
  cityMats.forEach(m => m.color.setScalar(ck));
  bloom.strength = 0.4 + 0.08 * env;
  composer.render();
  // subtitle
  let html = '', who = 'h'; for (const s of SUBS) if (t >= s[0] && t < s[1]) { html = s[2]; who = s[3]; }
  subEl.className = who === 'c' ? 'c' : '';
  if (subEl.dataset.h !== html) { subEl.innerHTML = html; subEl.dataset.h = html; }
  return true;
};

(async () => {
  try { ENV = await (await fetch('/projeto/env.json')).json(); } catch (e) { console.log('no env'); }
  await Promise.all(['700 40px Montserrat', '800 40px Montserrat', '900 40px Montserrat', '600 40px Montserrat'].map(f => document.fonts.load(f)));
  ambient.forEach((a, i) => { drawAmbient(a.ctx, i); a.tex.needsUpdate = true; });
  window.renderFrame(0);
  window.ready = true;
})();


// ================= VIDEOS NO "QUARTO" (telão + clipador + amigo + Claude) =================
// Anexado ao fim de uma copia de main.js (build-quarto.mjs). window.VIDEO escolhe o roteiro em quarto-videos.js.
{
  const VID = 'blender';
  const V = QV[VID];
  V.cine = true; V.ugly = V.feio || V.ugly || [-1, -1]; V.cards = V.cards && V.cards.length ? V.cards : [[0, '#07060c', () => {}]];
  const DUR = V.dur; window.DURATION = DUR;
  const winMax = (t, list, f = 0.2) => (list || []).reduce((m, [a, b]) => Math.max(m, win(t, a, b, f)), 0);
  const LN = V.lines, CUTS = V.cuts.concat([[DUR + 1, 'END']]);
  const PLANO = VID === 'plano', FESTA = VID === 'festa', BLENDER = VID === 'blender', CINE = !!V.cine;
  const talking = (who, t) => LN.find(l => l[2] === who && t >= l[0] && t < l[1]);
  const hash = i => { const s = Math.sin(i * 127.1) * 43758.5453; return s - Math.floor(s); };

  if (V.heroi) { const map = { 0x1fa79c: V.heroi.capuz, 0x178178: V.heroi.capuzEscuro || (V.heroi.capuz && '#' + new THREE.Color(V.heroi.capuz).multiplyScalar(0.78).getHexString()), 0xf3bea6: V.heroi.pele, 0xe2a48e: V.heroi.nariz || (V.heroi.pele && '#' + new THREE.Color(V.heroi.pele).multiplyScalar(0.9).getHexString()), 0x2b1b22: V.heroi.cabelo, 0x242a4c: V.heroi.calca };
    hero.g.traverse(o => { if (o.material && o.material.color) { const c = map[o.material.color.getHex()]; if (c) { o.material = o.material.clone(); o.material.color.set(c); } } }); }
  { // visual do personagem e do robo escolhidos pela pessoa (roteiro: heroi / robo)
    const HI = V.heroi || {};
    if (HI.bone) { for (let i = 4; i <= 8; i++) hero.head.children[i].visible = false;
      const cm = mat(new THREE.Color(HI.bone).getHex()); const dome = mesh(new THREE.IcosahedronGeometry(0.47, 1), cm, 0, 0.5, -0.02, hero.head); dome.scale.set(1.03, 0.72, 1.05);
      const brim = mesh(new THREE.BoxGeometry(0.52, 0.035, 0.3), cm, 0, 0.5, 0.44, hero.head); brim.rotation.x = 0.12; }
    if (HI.fone === false) hero.head.children.forEach(o => { const c = o.material && o.material.color && o.material.color.getHex(); if (c === 0x15131f || c === 0x5fe0ff) o.visible = false; });
    if (HI.oculos) { const om = mat(new THREE.Color(HI.oculos === true ? '#1a1a1a' : HI.oculos).getHex(), { roughness: 0.4 });
      for (const s of [-1, 1]) { const r = mesh(new THREE.TorusGeometry(0.078, 0.014, 6, 18), om, s * 0.15, 0.36, 0.415, hero.head); r.castShadow = false; }
      mesh(new THREE.BoxGeometry(0.08, 0.016, 0.016), om, 0, 0.375, 0.42, hero.head).castShadow = false; }
    const RB = V.robo || {};
    if (RB.cor) { const c = new THREE.Color(RB.cor); bot.coral.color.copy(c); bot.coral.emissive.copy(c).multiplyScalar(0.9); bot.coralD.color.copy(c).multiplyScalar(0.78); bot.coralD.emissive.copy(c).multiplyScalar(0.8); halo.material.color.copy(c).lerp(new THREE.Color(1, 1, 1), 0.3); }
  }
  { // estilo do corpo: lowpoly (padrao), quadrado, redondo, realista
    const est = (V.heroi || {}).estilo || 'lowpoly';
    const restyle = (root, est, skip) => root.traverse(o => {
      if (!o.isMesh || !o.geometry.parameters || (skip && skip.has(o)) || o.material.isMeshBasicMaterial) return;
      const p = o.geometry.parameters, T = o.geometry.type; let ng = null;
      if (est === 'redondo' || est === 'realista') {
        if (T === 'IcosahedronGeometry') ng = new THREE.SphereGeometry(p.radius, 40, 28);
        else if (T === 'BoxGeometry') ng = new RoundedBoxGeometry(p.width, p.height, p.depth, 5, Math.min(p.width, p.height, p.depth) * (est === 'redondo' ? 0.48 : 0.22));
        else if (T === 'ConeGeometry') ng = new THREE.ConeGeometry(p.radius, p.height, 18);
        else if (T === 'CylinderGeometry') ng = new THREE.CylinderGeometry(p.radiusTop, p.radiusBottom, p.height, 32);
        o.material = o.material.clone(); o.material.flatShading = false; o.material.needsUpdate = true;
        if (est === 'realista') { o.material.roughness = 0.62; }
      } else if (est === 'quadrado') {
        if (T === 'IcosahedronGeometry') { const d = p.radius * 1.75; ng = new THREE.BoxGeometry(d, d, d); }
        else if (T === 'ConeGeometry') ng = new THREE.BoxGeometry(p.radius * 1.5, p.height * 0.55, p.radius * 1.1);
        else if (T === 'CylinderGeometry') { const d = Math.max(p.radiusTop, p.radiusBottom) * 1.8; ng = new THREE.BoxGeometry(d, p.height, d); }
      }
      if (ng) o.geometry = ng;
    });
    if (est !== 'lowpoly') {
      const H = hero.head, capHair = H.children[3];
      restyle(hero.g, est, new Set(est === 'quadrado' ? [capHair] : []));
      if (est === 'quadrado') {   // cabelo em blocos: tampa em cima + nuca, sem cobrir o rosto
        capHair.geometry = new THREE.BoxGeometry(0.8, 0.24, 0.8); capHair.scale.set(1, 1, 1); capHair.position.set(0, 0.8, -0.02);
        const nuca = mesh(new THREE.BoxGeometry(0.8, 0.5, 0.22), capHair.material, 0, 0.55, -0.31, H);
        for (let i = 4; i <= 8; i++) { H.children[i].rotation.set(0, 0, 0); H.children[i].position.y = 0.66; }
      }
      if (est === 'redondo') H.scale.setScalar(1.08);
      if (est === 'realista') { H.scale.setScalar(0.86); H.children.forEach(o => { if (o.isGroup) { o.scale.x *= 0.8; o.scale.z *= 0.8; } }); }
      if (est === 'realista') {   // pele e tecido com brilho suave, olhos com reflexo
        hero.g.traverse(o => { if (o.isMesh && o.material.isMeshStandardMaterial && !o.material.isMeshPhysicalMaterial) {
          const m = new THREE.MeshPhysicalMaterial({ color: o.material.color, roughness: 0.58, sheen: 0.6, sheenRoughness: 0.5, sheenColor: o.material.color.clone().lerp(new THREE.Color(1, 1, 1), 0.4) }); o.material = m; } });
      }
    }
    const rest = (V.robo || {}).estilo;
    if (rest === 'redondo') { bot.body.geometry = new RoundedBoxGeometry(0.86, 0.74, 0.7, 6, 0.34); }
    if (rest === 'quadrado') { bot.body.geometry = new THREE.BoxGeometry(0.86, 0.74, 0.7); restyle(bot.g, 'quadrado', new Set([bot.body])); }
  }
  mainP.p.visible = false; rivalP.p.visible = false; ambient.forEach(a => (a.p.visible = false));
  rival.g.visible = false; divider.visible = false; coldLight.intensity = 0;
  scene.add(key.target);

  // ---------- quarto ----------
  const room = new THREE.Group(); scene.add(room);
  const wallM = new THREE.MeshStandardMaterial({ color: 0x17131f, roughness: 0.92 });
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(12, 8), wallM); wall.position.set(0, 4, -2.4); wall.receiveShadow = true; room.add(wall);
  for (const s of [-1, 1]) { const sw = new THREE.Mesh(new THREE.PlaneGeometry(9, 8), wallM); sw.position.set(s * 3.2, 4, 1.5); sw.rotation.y = -s * Math.PI / 2; room.add(sw); }
  for (let i = 0; i < 7; i++) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.02, 8, 0.02), new THREE.MeshStandardMaterial({ color: 0x0d0b14 })); p.position.set(-3 + i, 4, -2.39); room.add(p); }
  // telão
  const TLW = 2.2, TLH = 1.54, TLY = 3.05, TLZ = -2.33;
  const bezel = new THREE.Mesh(new RoundedBoxGeometry(TLW + 0.12, TLH + 0.12, 0.08, 3, 0.04), new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.25 })); bezel.position.set(0, TLY, TLZ - 0.03); room.add(bezel);
  const tc = document.createElement('canvas'); tc.width = QTW; tc.height = QTH; const tx = tc.getContext('2d');
  const tTex = new THREE.CanvasTexture(tc); tTex.colorSpace = THREE.SRGBColorSpace; tTex.anisotropy = 8;
  const tMat = new THREE.MeshBasicMaterial({ map: tTex, toneMapped: false, fog: false }); tMat.color.setScalar(0.82);
  const telao = new THREE.Mesh(new THREE.PlaneGeometry(TLW, TLH), tMat); telao.position.set(0, TLY, TLZ + 0.02); room.add(telao);
  // neon e LEDs
  const neonL = glow(0xff3fa4), neonR = glow(0x4fd8ff), ledM = glow(0x9a6cff);
  for (const [s, m] of [[-1, neonL], [1, neonR]]) { const n = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.6, 0.04), m); n.position.set(s * 1.42, 2.6, -2.36); room.add(n); }
  const ledTop = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.03, 0.03), ledM); ledTop.position.set(0, 4.15, -2.37); room.add(ledTop);
  const zero = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 28), neonL); zero.scale.y = 1.25; zero.position.set(-1.95, 3.3, -2.36); room.add(zero);
  const zero2 = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 28), neonR); zero2.scale.y = 1.25; zero2.position.set(1.95, 3.3, -2.36); room.add(zero2);
  // mesa
  const deskM = new THREE.MeshStandardMaterial({ color: 0x1d1826, roughness: 0.5, metalness: 0.2 });
  const desk = new THREE.Mesh(new THREE.BoxGeometry(3.3, 0.06, 0.78), deskM); desk.position.set(0, 0.9, -1.95); desk.castShadow = true; desk.receiveShadow = true; room.add(desk);
  for (const s of [-1, 1]) { const lg = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.88, 0.7), deskM); lg.position.set(s * 1.58, 0.44, -1.95); room.add(lg); }
  const deskLed = new THREE.Mesh(new THREE.BoxGeometry(3.3, 0.025, 0.025), ledM); deskLed.position.set(0, 0.86, -1.57); room.add(deskLed);
  // 3 monitores pequenos
  const minis = [[-0.92, 0.36], [0, 0], [0.92, -0.36]].map(([x, ry], i) => {
    const c = document.createElement('canvas'); c.width = 320; c.height = 200; const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
    const g = new THREE.Group(); g.position.set(x, 1.3, -2.08 + Math.abs(x) * 0.12); g.rotation.y = ry; room.add(g);
    g.add(new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.54, 0.04), new THREE.MeshStandardMaterial({ color: 0x08080c, roughness: 0.3 })));
    const p = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.48), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false })); p.position.z = 0.022; p.material.color.setScalar(0.75); g.add(p);
    const st = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.05), deskM); st.position.set(0, -0.36, -0.02); g.add(st);
    const bs = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.02, 0.18), deskM); bs.position.set(0, -0.37 - 0.09, 0); g.add(bs);
    return { ctx: c.getContext('2d'), tex };
  });
  const kb = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.02, 0.17), new THREE.MeshStandardMaterial({ color: 0x0c0c12, roughness: 0.4 })); kb.position.set(0, 0.945, -1.72); room.add(kb);
  const kbLed = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.006, 0.12), glow(0x5fe0ff, { transparent: true, opacity: 0.55 })); kbLed.position.set(0, 0.958, -1.72); room.add(kbLed);
  // latinhas organizadas
  const canM = new THREE.MeshStandardMaterial({ color: 0x2b4fb8, roughness: 0.3, metalness: 0.7 }), canT = new THREE.MeshStandardMaterial({ color: 0xc8ccd6, roughness: 0.3, metalness: 0.9 });
  const cans = [];
  for (let i = 0; i < 6; i++) { const g = new THREE.Group(); g.position.set(-1.42 + i * 0.085, 0.93, -1.68); room.add(g);
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.034, 0.13, 12), canM); b.position.y = 0.065; g.add(b);
    const tp = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.034, 0.012, 12), canT); tp.position.y = 0.136; g.add(tp);
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.0345, 0.0345, 0.03, 12), glow(0xc8d4ff, { transparent: true, opacity: 0.7 })); st.position.y = 0.07; g.add(st); cans.push(g); }
  // gabinete com RGB
  const pc = new THREE.Group(); pc.position.set(1.36, 0.93, -1.98); room.add(pc);
  pc.add(new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.5, 0.46), new THREE.MeshStandardMaterial({ color: 0x0b0b10, roughness: 0.3, metalness: 0.4 }))); pc.children[0].position.y = 0.25;
  const fans = [0.14, 0.34].map((y, i) => { const f = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.012, 6, 20), glow(i ? 0x4fd8ff : 0xff3fa4)); f.position.set(0, y, 0.235); pc.add(f); return f; });
  // celular num suporte (usado no video da festa)
  const phone = new THREE.Group(); phone.position.set(0.55, 1.13, -1.72); phone.rotation.x = -0.22; room.add(phone); phone.visible = FESTA;
  const phC = document.createElement('canvas'); phC.width = 200; phC.height = 400; const phX = phC.getContext('2d'); const phTex = new THREE.CanvasTexture(phC); phTex.colorSpace = THREE.SRGBColorSpace;
  phone.add(new THREE.Mesh(new RoundedBoxGeometry(0.2, 0.4, 0.02, 3, 0.02), new THREE.MeshStandardMaterial({ color: 0x0a0a0e, roughness: 0.25 })));
  const phScr = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 0.38), new THREE.MeshBasicMaterial({ map: phTex, toneMapped: false })); phScr.position.z = 0.011; phone.add(phScr);
  const phRing = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.012, 8, 40), glow(0xffb48c, { transparent: true, opacity: 0 })); phRing.position.set(0.55, 1.13, -1.7); room.add(phRing);
  const phStand = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.03, 0.12), deskM); phStand.position.set(0.55, 0.945, -1.76); room.add(phStand); phStand.visible = FESTA;
  // luzes do quarto
  const lightL = new THREE.PointLight(0xff3fa4, 6, 8, 1.6); lightL.position.set(-2.2, 2.5, -1.0); scene.add(lightL);
  const lightR = new THREE.PointLight(0x4fd8ff, 5, 8, 1.6); lightR.position.set(2.2, 2.3, -0.8); scene.add(lightR);
  const lightT = new THREE.PointLight(0xfff0e0, 3, 7, 1.5); lightT.position.set(0, 2.9, -1.2); scene.add(lightT);

  // ---------- personagens ----------
  const friend = buildKid({ skin: 0xc48a66, nose: 0xae7653, hood: 0xd23a3a, hoodD: 0xa32828, pants: 0x1c1c26, hair: 0x1a1414, string: 0xffffff });
  scene.add(friend.g);
  for (let i = 4; i <= 8; i++) friend.head.children[i].visible = false;        // sem franja: usa bone
  { const cm = mat(0x1d1d28); const dome = mesh(new THREE.IcosahedronGeometry(0.47, 1), cm, 0, 0.5, -0.02, friend.head); dome.scale.set(1.03, 0.72, 1.05);
    const brim = mesh(new THREE.BoxGeometry(0.52, 0.035, 0.3), cm, 0, 0.5, 0.44, friend.head); brim.rotation.x = 0.12;
    mesh(new THREE.BoxGeometry(0.16, 0.1, 0.02), glow(0xffd166), 0, 0.62, 0.43, friend.head); }
  const neck = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.022, 8, 24), glow(0x7CFC8A)); neck.rotation.x = Math.PI / 2 - 0.25; neck.position.set(0, 0.6, 0.06); friend.body.add(neck); neck.visible = FESTA;
  // garrafa na mao direita do clipador (video do plano)
  const bottle = new THREE.Group(); bottle.position.set(0, -0.52, 0.02); bottle.rotation.x = Math.PI / 2; hero.armR.add(bottle); bottle.visible = PLANO;
  const btlM = new THREE.MeshPhysicalMaterial({ color: 0x0f3a22, roughness: 0.2, clearcoat: 1 }), goldM = new THREE.MeshStandardMaterial({ color: 0xd9b24c, roughness: 0.35, metalness: 0.8 });
  mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.26, 10), btlM, 0, 0.1, 0, bottle); mesh(new THREE.CylinderGeometry(0.02, 0.05, 0.1, 10), btlM, 0, 0.28, 0, bottle);
  mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.1, 8), goldM, 0, 0.37, 0, bottle); mesh(new THREE.CylinderGeometry(0.0565, 0.0565, 0.09, 10), mat(0xf0e6d0), 0, 0.1, 0, bottle);
  const tip = new THREE.Object3D(); tip.position.y = 0.43; bottle.add(tip);
  const foam = []; for (let i = 0; i < 40; i++) { const f = new THREE.Mesh(new THREE.IcosahedronGeometry(0.022, 0), glow(0xfff6dc, { transparent: true })); scene.add(f); f.visible = false; foam.push(f); }
  const confetti = []; for (let i = 0; i < 80; i++) { const c = new THREE.Mesh(new THREE.PlaneGeometry(0.05, 0.09), glow([0xffd166, 0xff4fa8, 0x5fe0ff, 0x7CFC8A, 0xff7a45][i % 5], { side: THREE.DoubleSide, transparent: true })); scene.add(c); c.visible = false; confetti.push(c); }
  // tacas
  const glassM = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transparent: true, opacity: 0.32, side: THREE.DoubleSide, depthWrite: false });
  const champM = new THREE.MeshStandardMaterial({ color: 0xf2d27a, roughness: 0.2, emissive: 0x6a5010 });
  function makeGlass() { const g = new THREE.Group(); mesh(new THREE.CylinderGeometry(0.04, 0.045, 0.01, 10), glassM, 0, 0.005, 0, g); mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.13, 6), glassM, 0, 0.07, 0, g);
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.02, 0.17, 10, 1, true), glassM); b.position.y = 0.22; g.add(b); mesh(new THREE.CylinderGeometry(0.038, 0.02, 0.1, 10), champM, 0, 0.19, 0, g); return g; }
  const botGlass = makeGlass(); scene.add(botGlass); botGlass.visible = PLANO;
  const botGlassRing = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.008, 6, 24), glow(0xffe2c2, { transparent: true, opacity: 0.8 })); botGlassRing.rotation.x = Math.PI / 2; botGlass.add(botGlassRing);
  const frGlass = makeGlass(); frGlass.position.set(0, -0.52, 0.02); frGlass.rotation.x = Math.PI / 2; friend.armR.add(frGlass); frGlass.visible = false;

  // rua com os dois carros (final do video da festa)
  const CARX = 24; const cars = [];
  if (FESTA) for (const [col, z] of [[0xff7a45, 1.2], [0x22d3c5, -0.6]]) {
    const g = new THREE.Group(); scene.add(g); const pm = new THREE.MeshPhysicalMaterial({ color: col, roughness: 0.25, clearcoat: 1, metalness: 0.3 });
    const b = new THREE.Mesh(new RoundedBoxGeometry(2.3, 0.36, 0.95, 3, 0.1), pm); b.position.y = 0.36; b.castShadow = true; g.add(b);
    const cab = new THREE.Mesh(new RoundedBoxGeometry(1.05, 0.3, 0.8, 3, 0.1), new THREE.MeshStandardMaterial({ color: 0x0a0a12, roughness: 0.1, metalness: 0.6 })); cab.position.set(-0.15, 0.66, 0); g.add(cab);
    for (const [wx, wz] of [[-0.75, 0.48], [0.75, 0.48], [-0.75, -0.48], [0.75, -0.48]]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.16, 12), new THREE.MeshStandardMaterial({ color: 0x0c0c10, roughness: 0.6 })); w.rotation.x = Math.PI / 2; w.position.set(wx, 0.2, wz); g.add(w); }
    for (const s of [-1, 1]) { const hl = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.07, 0.2), glow(0xfff4d0)); hl.position.set(1.16, 0.4, s * 0.3); g.add(hl); const tl = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.06, 0.24), glow(0xff2a3a)); tl.position.set(-1.16, 0.42, s * 0.3); g.add(tl); }
    const ul = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.9), glow(col, { transparent: true, opacity: 0.35 })); ul.rotation.x = -Math.PI / 2; ul.position.y = 0.03; g.add(ul);
    g.userData.z = z; cars.push(g);
  }

  // ---------- telão e telas pequenas ----------
  const H = {
    x: tx, sm: smooth, clamp,
    fnt: (px, w = 700, fam = "'Segoe UI', sans-serif") => { tx.font = `${w} ${px}px ${fam}`; },
    box: (X, Y, W_, H_, R, fill, stroke, lw = 4) => { tx.beginPath(); tx.roundRect(X, Y, W_, H_, R); if (fill) { tx.fillStyle = fill; tx.fill(); } if (stroke) { tx.strokeStyle = stroke; tx.lineWidth = lw; tx.stroke(); } },
    txt: (s, X, Y, col, al = 'left') => { tx.textAlign = al; tx.fillStyle = col; tx.fillText(s, X, Y); tx.textAlign = 'left'; },
    pop: (t, t0, d = 0.28) => { const k = clamp((t - t0) / d); return k <= 0 ? 0 : back(k); },
  };
  function drawTelao(t) {
    let i = 0; while (i < V.cards.length - 1 && t >= V.cards[i + 1][0]) i++;
    const [t0, bg, fn] = V.cards[i];
    tx.globalAlpha = 1; tx.shadowBlur = 0; tx.textBaseline = 'alphabetic'; tx.textAlign = 'left'; tx.setLineDash([]);
    tx.fillStyle = bg; tx.fillRect(0, 0, QTW, QTH);
    const a = i === 0 ? 1 : smooth(t0, t0 + 0.16, t);
    tx.save(); tx.globalAlpha = a; tx.translate(0, (1 - a) * 30); fn(t, H); tx.restore();
    tTex.needsUpdate = true;
  }
  function drawMinis(t) {
    minis.forEach((m, k) => { const x = m.ctx; x.fillStyle = '#0b0d16'; x.fillRect(0, 0, 320, 200);
      if (k === 0) { for (let i = 0; i < 9; i++) { const w = 60 + hash(i + Math.floor(t * 2)) * 200; x.fillStyle = ['#5fe0ff', '#ff4fa8', '#a98bff', '#7CFC8A'][i % 4]; x.globalAlpha = 0.8; x.fillRect(16 + (i % 3) * 14, 14 + i * 20, w, 9); } x.globalAlpha = 1; }
      else if (k === 1) { x.fillStyle = '#1a2036'; x.fillRect(0, 130, 320, 70); for (let i = 0; i < 40; i++) { const hh = 10 + 60 * Math.abs(Math.sin(i * 1.7 + t * 5)) * (0.4 + hash(i)); x.fillStyle = '#ff7a45'; x.fillRect(8 + i * 7.7, 80 - hh / 2, 5, hh); } x.fillStyle = '#ffd166'; x.fillRect((t * 40) % 320, 130, 3, 70); for (let i = 0; i < 5; i++) { x.fillStyle = ['#7b3cff', '#22d3c5', '#ff2e88'][i % 3]; x.fillRect(10 + i * 62, 142 + (i % 2) * 26, 52, 18); } }
      else { for (let i = 0; i < 8; i++) { const hh = 30 + 130 * (0.5 + 0.5 * Math.sin(i * 0.9 + t * 1.5)) * (i + 3) / 11; x.fillStyle = i === 7 ? '#7CFC8A' : '#3b6cff'; x.fillRect(24 + i * 36, 180 - hh, 24, hh); } }
      m.tex.needsUpdate = true; });
  }
  function drawPhone(t) {
    const x = phX; const g = x.createLinearGradient(0, 0, 0, 400); g.addColorStop(0, '#2a1650'); g.addColorStop(1, '#0c0a18'); x.fillStyle = g; x.fillRect(0, 0, 200, 400);
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = '700 54px Montserrat'; x.fillText('23:47', 100, 90);
    const n = t >= 44.34 ? 2 : t >= 42.34 ? 1 : 0;
    for (let i = 0; i < n; i++) { const t0 = i ? 44.34 : 42.34, k = clamp((t - t0) / 0.2); x.globalAlpha = k; x.fillStyle = 'rgba(255,255,255,.14)'; x.beginPath(); x.roundRect(12, 130 + i * 92, 176, 78, 14); x.fill(); x.fillStyle = '#7CFC8A'; x.font = '800 21px Montserrat'; x.fillText('Venda aprovada', 100, 164 + i * 92); x.fillStyle = '#cfc8e0'; x.font = '600 16px sans-serif'; x.fillText('agora', 100, 190 + i * 92); x.globalAlpha = 1; }
    if (t >= 48.3) { x.fillStyle = 'rgba(0,0,0,.6)'; x.fillRect(0, 0, 200, 400); x.fillStyle = '#fff'; x.font = '800 22px Montserrat'; x.fillText('SILENCIOSO', 100, 210); }
    x.textAlign = 'left'; phTex.needsUpdate = true;
  }

  // ---------- planos (com movimento) ----------
  const SHOTS = {
    W: { p: [0, 2.0, 7.4], q: [0, 1.95, -0.6], d: [0, 0, -0.45] },
    WB: { p: [0, 2.3, 6.2], q: [0, 2.3, -1.2], d: [0, 0.1, 0.9] },
    PF: { p: [0, 2.6, 4.75], q: [0, 2.55, -2.33], d: [0, 0, -0.22], turn: true },
    H: { p: [0.3, 1.8, 3.6], q: [-0.6, 1.64, 0], d: [-0.12, 0, -0.2] },
    A: { p: [0.05, 1.8, 3.6], q: [0.8, 1.64, 0], d: [0.12, 0, -0.2] },
    B: { p: [0.5, 2.1, 2.5], q: [0.1, 2.05, -0.55], d: [-0.1, 0, -0.14] },
    TS: { p: [0.1, 1.75, 5.0], q: [0.1, 1.62, 0], d: [0, 0, -0.3] },
    LOW: { p: [-1.7, 0.55, 4.3], q: [-0.5, 1.75, 0], d: [0.35, 0.05, -0.2] },
    CAN: { p: [-1.2, 1.32, -0.7], q: [-1.2, 1.0, -1.72], d: [0.06, 0, -0.1] },
    PH: { p: [0.42, 1.5, -0.2], q: [0.52, 1.12, -1.72], d: [0.05, 0, -0.14] },
    CAR: { p: [CARX, 1.7, 7.6], q: [CARX, 0.75, -3], d: [0, 0.35, -0.5] },
    // video "blender" (clipador em x -0.4, Claude em x 0.5)
    CH: { p: [0.25, 1.8, 3.5], q: [-0.4, 1.68, 0], d: [-0.1, 0, -0.3] },
    LOWH: { p: [0.05, 0.95, 3.0], q: [-0.42, 1.78, 0], d: [0.12, 0.05, -0.1] },
    CC: { p: [1.45, 2.2, 4.3], q: [0.5, 2.0, -0.45], d: [-0.08, 0, -0.25] },
    PFC: { p: [0, 2.6, 5.3], q: [0, 2.6, -2.33], d: [0, 0, -0.35], turn: true },
    UG: { p: [0, 1.85, 5.4], q: [0, 1.55, -0.6], d: [0, 0, 0], still: true },
    UGH: { p: [-0.1, 1.75, 3.4], q: [-0.4, 1.62, 0], d: [0, 0, 0], still: true },
    UGC: { p: [0.75, 2.05, 2.9], q: [0.5, 2.0, -0.45], d: [0, 0, 0], still: true },
    REV: { p: [0.25, 1.6, 5.4], q: [0, 1.85, -0.8], d: [-0.15, 0.25, -1.4], ease: true },
    OTS: { p: [3.3, 2.0, 2.5], q: [0, 1.85, -0.2], d: [-0.25, 0, -0.3] },
    ORB: { orbit: [0.05, 1.85, -0.2, 4.7, 0.4, -0.15, 1.95], q: [0.05, 1.8, -0.2] },
    ORB2: { orbit: [0.05, 1.85, -0.2, 4.3, 1.0, -0.6, 2.2], q: [0.05, 1.85, -0.2] },
    W2: { p: [0, 2.05, 5.6], q: [0, 1.8, -0.8], d: [0, 0, -0.6] },
    MOUTH: { p: [0.25, 1.62, 1.95], q: [-0.38, 1.55, 0.05], d: [0, 0, -0.1] },
    END: { p: [0, 2.4, 4.4], q: [0, 2.55, -2.33], d: [0, 0.2, 1.8], turn: true },
  };
  const vp = new THREE.Vector3(), vq = new THREE.Vector3();
  function cam(t) {
    let i = 0; while (i < CUTS.length - 2 && t >= CUTS[i + 1][0]) i++;
    const name = CUTS[i][1], s = SHOTS[name], lt = t - CUTS[i][0], k = clamp(lt / Math.max(1.2, CUTS[i + 1][0] - CUTS[i][0]));
    vq.set(...s.q);
    if (s.orbit) { const [cx, cy, cz, r, a0, a1, hy] = s.orbit, a = a0 + (a1 - a0) * smooth(0, 1, k); vp.set(cx + Math.sin(a) * r, hy, cz + Math.cos(a) * r); }
    else { const kk = s.ease ? 1 - Math.pow(1 - k, 3) : k; vp.set(s.p[0] + s.d[0] * kk, s.p[1] + s.d[1] * kk, s.p[2] + s.d[2] * kk); }
    if (!s.still) { vp.x += Math.sin(t * 0.7) * 0.025 + (CINE ? 0.008 * Math.sin(t * 2.3) : 0); vp.y += Math.sin(t * 0.53 + 1.3) * 0.016 + (CINE ? 0.006 * Math.sin(t * 3.1 + 2) : 0); }
    camera.fov = (s.fov || (CINE ? 33 : 35)) * (1 + (s.still ? 0 : CINE ? 0.035 : 0.07) * (1 - smooth(0, 0.3, lt))); camera.updateProjectionMatrix();   // "soco" de zoom a cada corte
    camera.position.copy(vp); camera.lookAt(vq);
    return { name, turn: !!s.turn, still: !!s.still, scr: !!s.scr, focus: vp.distanceTo(vq) };
  }

  // ---------- atuacao ----------
  function gesture(P, o, w, t, t0) {
    const g = o.g, e = o.e;
    if (g === 'up') { P.aLz -= 2.4 * w; P.aRz += 2.3 * w; P.hop += 0.09 * w * Math.abs(Math.sin((t - t0) * 9)); }
    if (g === 'point') { P.aLx -= 1.5 * w; P.aLz -= 0.2 * w; }
    if (g === 'shrug') { P.aLz -= 0.7 * w; P.aRz += 0.7 * w; P.aLx -= 0.45 * w; P.aRx -= 0.45 * w; P.hr += 0.1 * w; }
    if (g === 'no') { P.hy += 0.3 * w * Math.sin((t - t0) * 18); }
    if (g === 'chest') { P.aLx -= 1.15 * w; P.aLz += 0.55 * w; }
    if (g === 'think') { P.aLx -= 2.3 * w; P.aLz += 0.35 * w; P.hr += 0.08 * w; }
    if (g === 'beg') { P.aLx -= 1.35 * w; P.aRx -= 1.35 * w; P.aLz += 0.32 * w; P.aRz -= 0.32 * w; P.brow += 0.05 * w; P.eye += 0.2 * w; P.lean += 0.1 * w; }
    if (g === 'annoy') { P.aLx -= 0.85 * w; P.aLz += 0.6 * w; P.aRx -= 0.85 * w; P.aRz -= 0.6 * w; P.browT -= 0.3 * w; P.mouth -= 1.2 * w; }
    if (g === 'shock') { P.eye += 0.38 * w; P.brow += 0.07 * w; P.open = Math.max(P.open, 0.45 * w); P.aLz -= 0.9 * w; P.aRz += 0.9 * w; P.lean -= 0.1 * w; }
    if (g === 'one') { P.aLx -= 2.85 * w; P.aLz -= 0.1 * w; }
    expr(P, e, w);
  }
  function expr(P, e, w) {
    if (e === 'happy') { P.mouth += 0.5 * w; P.eye += 0.1 * w; P.brow += 0.02 * w; }
    if (e === 'proud') { P.hp -= 0.14 * w; P.mouth += 0.45 * w; P.browT -= 0.1 * w; }
    if (e === 'conf') { P.hr += 0.13 * w; P.browT -= 0.12 * w; P.mouth -= 0.6 * w; P.eye += 0.1 * w; }
    if (e === 'sus') { P.eye -= 0.32 * w; P.browT -= 0.2 * w; P.hr -= 0.08 * w; P.mouth -= 0.7 * w; }
    if (e === 'off') { P.browT -= 0.34 * w; P.mouth -= 1.3 * w; P.eye += 0.12 * w; P.hp -= 0.08 * w; }
    if (e === 'sad') { P.hp += 0.3 * w; P.mouth -= 1.5 * w; P.browT += 0.22 * w; P.eye -= 0.15 * w; P.lean += 0.1 * w; }
  }
  function actor(who, t, turn) {
    const hero_ = who === 'h';
    const P = { x: hero_ ? -0.62 : 0.8, z: 0, hop: 0, yaw: hero_ ? 0.22 : -0.3, lean: 0, hp: 0.02 * Math.sin(t * 1.3 + (hero_ ? 0 : 2)), hy: 0, hr: 0.02 * Math.sin(t * 0.9 + (hero_ ? 1 : 0)), aLx: 0, aLz: -0.1, aRx: 0, aRz: 0.1, eye: 1, brow: 0, browT: 0, mouth: 0.55, open: 0 };
    for (const ln of LN) {
      const w = win(t, ln[0], ln[1] + 0.12, 0.24); if (w < 0.001) continue; const o = ln[4];
      if (ln[2] === who) gesture(P, o, w, t, ln[0]);
      else {
        if (hero_) { if (ln[2] === 'a') P.hy += 0.42 * w; else { P.hy += 0.2 * w; P.hp -= 0.16 * w; } if (o.hr) expr(P, o.hr, w); }
        else { if (ln[2] === 'h') P.hy -= 0.42 * w; else { P.hy -= 0.28 * w; P.hp -= 0.16 * w; } if (o.ar) expr(P, o.ar, w); }
      }
    }
    return P;
  }
  function faceScreen(P, who, t) { P.yaw = who === 'h' ? Math.PI - 0.25 : Math.PI + 0.3; P.hy = 0; P.hp = -0.28; P.hr = 0; P.lean = -0.04; if (talking(who, t)) { P.aLx = -2.3; P.aLz = who === 'h' ? 0.25 : -0.25; } }

  function botAt(t, env, x, y, z, yaw, pitch, extraRoll = 0) {
    let roll = 0.04 * Math.sin(t * 1.3) + extraRoll, eL = 1, eR = 1, ringAmp = 0;
    for (const ln of LN) { const w = win(t, ln[0], ln[1], 0.22); if (w < 0.001 || ln[2] !== 'c') continue; roll += 0.09 * w; eL *= 1 - 0.22 * w; eR *= 1 - 0.22 * w; ringAmp = Math.max(ringAmp, 0.5 * w * Math.min(1, env * 2.4)); }
    const bl = blink(t, 1.4);
    bot.g.position.set(x, y + 0.05 * Math.sin(t * 1.9), z); bot.g.rotation.set(pitch, yaw, roll);
    bot.eyeL.scale.y = Math.max(0.1, eL * bl); bot.eyeR.scale.y = Math.max(0.1, eR * bl);
    bot.bulbM.color.setScalar(1).multiply(new THREE.Color(0xffe2c2)).multiplyScalar(0.7 + 0.9 * env);
    bot.thr.scale.setScalar(0.9 + 0.15 * Math.sin(t * 9));
    const breath = 0.5 + 0.16 * Math.sin(t * 1.7) + 0.45 * ringAmp + 0.2 * env;
    bot.coral.emissiveIntensity = breath; bot.coralD.emissiveIntensity = 0.12 + breath * 0.35; bot.inner.intensity = 1.2 + 2.4 * breath;
    halo.position.copy(bot.g.position); halo.position.z -= 0.05; halo.material.opacity = 0.14 + 0.28 * breath;
    for (let i = 0; i < 3; i++) { const ph = (t * 0.9 + i / 3) % 1; const s = 0.75 + ph * 0.95; bot.rings[i].scale.set(s, s, 1);
      bot.rings[i].material.opacity = ringAmp * Math.sin(Math.PI * ph) * 0.42; bot.rings[i].quaternion.copy(bot.g.quaternion).invert().multiply(camera.quaternion); }
  }
  const botLook = t => { let y = 0; for (const ln of LN) { const w = win(t, ln[0], ln[1], 0.25); if (ln[2] === 'h') y -= 0.4 * w; if (ln[2] === 'a') y += 0.4 * w; } return y; };

  const tipW = new THREE.Vector3();
  function framePlano(t, env, shot) {
    const P = actor('h', t), A = actor('a', t);
    // garrafa: segura na altura do peito; no comeco, sacode pro alto
    const cheer = 1 - smooth(3.4, 4.2, t), toast = smooth(54.8, 55.2, t);
    P.aRx = -1.05 - 1.25 * cheer - 1.2 * toast + 0.22 * cheer * Math.sin(t * 15); P.aRz = 0.15 + 0.2 * cheer;
    P.hop += 0.07 * cheer * Math.abs(Math.sin(t * 8)) + 0.05 * toast * Math.abs(Math.sin(t * 7));
    // amigo entra pela direita
    const inn = smooth(5.5, 6.5, t); A.x = lerp(2.6, 0.8, inn); A.hop += 0.07 * (1 - inn) * Math.abs(Math.sin(t * 13)) * (t > 5.5 ? 1 : 0);
    if (t >= 54.2) { A.aRx = -1.15 - 1.25 * toast; A.aRz = 0.15; A.mouth += 0.5; }
    if (shot.turn) { faceScreen(P, 'h', t); faceScreen(A, 'a', t); P.aRx = -1.05; }
    if (talking('h', t) && env > 0.1) P.open = Math.max(P.open, Math.min(1, 0.08 + env * 1.15));
    if (talking('a', t) && env > 0.1) A.open = Math.max(A.open, Math.min(1, 0.08 + env * 1.15));
    poseKid(hero, P, t, 0.3); poseKid(friend, A, t, 1.9); friend.g.visible = t >= 5.45; frGlass.visible = t >= 54.2;
    const spin = smooth(21.7, 22.6, t) * Math.PI * 2, raise = win(t, 5.35, 6.3, 0.2) + smooth(55.5, 55.9, t);
    botAt(t, env, 0.1, shot.turn ? 1.7 : 2.02, -0.55, botLook(t) + spin, shot.turn ? 0 : 0.06);
    botGlass.position.set(bot.g.position.x + 0.62, bot.g.position.y - 0.25 + 0.22 * raise, bot.g.position.z + 0.1); botGlass.rotation.z = -0.25 * raise;
    // espuma do espumante
    hero.g.updateMatrixWorld(true); tip.getWorldPosition(tipW);
    foam.forEach((f, i) => { const b = 0.3 + (i * 0.083) % 3.2, age = t - b - Math.floor((t - b) / 3.3) * 0; const a = t - b; f.visible = a > 0 && a < 0.9 && t < 4.4;
      if (f.visible) { f.position.set(tipW.x + (hash(i) - 0.5) * 1.1 * a, tipW.y + (1.6 + hash(i + 9)) * a - 2.6 * a * a, tipW.z + (hash(i + 5) - 0.2) * 0.8 * a); f.material.opacity = 1 - a / 0.9; f.scale.setScalar(1 + a * 1.5); } });
    const party = Math.max(win(t, 0.1, 5.6, 0.5), smooth(54.8, 55.1, t));
    confetti.forEach((c, i) => { c.visible = party > 0.02; if (!c.visible) return; const ph = (t * (0.22 + hash(i) * 0.12) + hash(i + 3)) % 1;
      c.position.set((hash(i + 1) - 0.5) * 3.6, 4.4 - ph * 4.6, 0.3 + hash(i + 2) * 1.6); c.rotation.set(t * 3 + i, t * 2.1 + i * 2, i); c.material.opacity = party; });
  }

  function frameFesta(t, env, shot) {
    const P = actor('h', t), A = actor('a', t);
    // clipador de costas, focado, ate "oferta milionaria"
    const faceCam = smooth(5.7, 6.15, t); if (faceCam < 1) { P.yaw = lerp(Math.PI - 0.25, 0.22 + Math.PI * 2 * 0, faceCam) ; P.aLx -= 0.9 * (1 - faceCam); P.aRx -= 0.9 * (1 - faceCam); if (faceCam === 0) { P.hy = 0.5 * win(t, 3.1, 3.8, 0.2); P.hp = 0.1; } }
    // amigo entra animado
    const inn = smooth(0.0, 0.95, t); A.x = lerp(2.6, 0.8, inn); A.hop += 0.07 * (1 - inn) * Math.abs(Math.sin(t * 13));
    // saida para a festa
    const out = smooth(56.7, 57.3, t);
    if (out > 0) { P.x += 3.6 * out; A.x += 3.6 * out; P.yaw = lerp(P.yaw, 1.45, Math.min(1, out * 3)); A.yaw = lerp(A.yaw, 1.45, Math.min(1, out * 3)); const hp_ = 0.08 * Math.abs(Math.sin(t * 13)); P.hop += hp_; A.hop += hp_; }
    if (shot.turn) { faceScreen(P, 'h', t); faceScreen(A, 'a', t); }
    if (talking('h', t) && env > 0.1) P.open = Math.max(P.open, Math.min(1, 0.08 + env * 1.15));
    if (talking('a', t) && env > 0.1) A.open = Math.max(A.open, Math.min(1, 0.08 + env * 1.15));
    poseKid(hero, P, t, 0.3); poseKid(friend, A, t, 1.9);
    const gone = t >= 57.3; hero.g.visible = !gone; friend.g.visible = !gone;
    // colar de festa: cai no "ta bom"
    const drop = smooth(54.5, 55.0, t); neck.visible = drop < 1; neck.position.y = 0.6 - 0.9 * drop; neck.scale.setScalar(1 - 0.5 * drop);
    // Claude: escondido atras do monitor ate "desde marco"
    const rise = smooth(7.85, 8.45, t), work = smooth(59.6, 60.5, t);
    bot.g.visible = rise > 0; halo.visible = rise > 0;
    botAt(t, env, 0.1, shot.turn ? 1.7 : lerp(1.0, 2.02, back(rise)), lerp(-1.25, -0.55, rise) - 0.5 * work, botLook(t) * (1 - work) + Math.PI * work, shot.turn ? 0 : 0.06, 0.25 * win(t, 12.6, 13.2, 0.15));
    // latinhas: uma some de fininho no "toma energetico"
    cans[5].position.x = -1.42 + 5 * 0.085 + 0.9 * smooth(31.75, 32.4, t); cans[5].position.z = -1.68 + 0.25 * smooth(31.75, 32.4, t);
    // celular vibrando e sendo silenciado
    const vib = Math.max(win(t, 41.1, 42.2, 0.08), win(t, 43.0, 44.1, 0.08));
    phone.rotation.z = 0.07 * vib * Math.sin(t * 95); phone.position.x = 0.55 + 0.012 * vib * Math.sin(t * 80);
    const flip = smooth(47.9, 48.5, t); phone.rotation.y = Math.PI * flip; phRing.material.opacity = 0.9 * win(t, 47.6, 48.9, 0.2); phRing.scale.setScalar(1.2 - 0.6 * smooth(47.6, 48.5, t)); phRing.rotation.set(0.2, t * 3, 0);
    drawPhone(t);
    // carros indo embora
    cars.forEach((c, i) => { const k = clamp((t - 57.2) / 1.4); c.rotation.y = Math.PI / 2; c.position.set(CARX + (i ? 0.95 : -0.95), 0, 2.4 - (k * k * 0.6 + k * 0.4) * (7.2 - i * 0.9) - i * 0.5); c.visible = t >= 57.15 && t < 58.6; });
    foam.forEach(f => (f.visible = false)); confetti.forEach(c => (c.visible = false));
    return work;
  }


  // ================= MODO CINEMA v2 (video "blender") =================
  // Cenario realista: quarto retro com sol de fim de tarde entrando pela persiana, madeira, computador antigo, estante,
  // abajur, planta e tapete. Sombras suaves (sol "de area" por sub-quadro), oclusao de ambiente (GTAO), motion blur e
  // anti-aliasing por acumulo de sub-quadros, foco seletivo, granulacao e cor de cinema. Personagens continuam low poly.
  const cine = { on: CINE, NS: 10, shutter: 0.5 / 30, sub: 0 };
  const ovl = id => document.getElementById(id);
  const tmpV = new THREE.Vector3(), tmpV2 = new THREE.Vector3();
  if (CINE) {
    const keep = new Set([hero.g, bot.g, halo]);
    cine.oldLights = [];
    scene.children.slice().forEach(o => { if (o.isLight) cine.oldLights.push(o); else if (!keep.has(o) && !o.isCamera) o.visible = false; });
    cine.bg = new THREE.Color(0x0b0806); cine.uglyBg = new THREE.Color(0x8c8c8c);
    scene.background = cine.bg;
    cine.fog = new THREE.FogExp2(0x24180f, 0.012); scene.fog = cine.fog;
    scene.environmentIntensity = 0.07; renderer.toneMappingExposure = 0.92;
    const set = new THREE.Group(); scene.add(set);
    const R = mulberry32(77);
    const cvTex = (w, h, fn, rep) => { const c = document.createElement('canvas'); c.width = w; c.height = h; fn(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...rep); } return t; };
    const box = (w, h, d, m, x, y, z, parent = set) => { const r = Math.min(0.014, Math.min(w, h, d) * 0.3); const o = new THREE.Mesh(r > 0.0025 ? new RoundedBoxGeometry(w, h, d, 2, r) : new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); o.castShadow = o.receiveShadow = true; parent.add(o); return o; };
    const woodTex = (base, planks, rep) => cvTex(1024, 1024, (x, w, h) => {
      const ph = h / planks;
      for (let i = 0; i < planks; i++) {
        const c = new THREE.Color(base); c.offsetHSL((R() - 0.5) * 0.015, (R() - 0.5) * 0.06, (R() - 0.5) * 0.07);
        x.fillStyle = '#' + c.getHexString(); x.fillRect(0, i * ph, w, ph);
        for (let k = 0; k < 46; k++) {
          x.strokeStyle = R() < 0.6 ? `rgba(30,15,5,${0.05 + R() * 0.08})` : `rgba(255,225,190,${0.03 + R() * 0.05})`; x.lineWidth = 0.8 + R() * 2.4; x.beginPath();
          const y0 = i * ph + R() * ph, a = R() * 6, f = 0.003 + R() * 0.008, amp = ph * (0.05 + R() * 0.12);
          for (let xx = 0; xx <= w; xx += 12) x.lineTo(xx, y0 + Math.sin(xx * f + a) * amp);
          x.stroke();
        }
        x.fillStyle = 'rgba(20,10,4,.55)'; x.fillRect(0, i * ph, w, Math.max(2, ph * 0.02)); x.fillRect(R() * w, i * ph, 3, ph);
      }
    }, rep);
    const plasterTex = cvTex(512, 512, (x, w, h) => { x.fillStyle = '#e8e2da'; x.fillRect(0, 0, w, h); for (let i = 0; i < 12000; i++) { const v = 170 + R() * 85 | 0; x.fillStyle = `rgba(${v},${v - 6},${v - 12},.22)`; const s = 1 + R() * 3; x.fillRect(R() * w, R() * h, s, s); } }, [3, 2]);
    const relief = (m, k) => { m.bumpMap = m.map; m.bumpScale = k; m.roughnessMap = m.map; return m; };
    const floorM = relief(new THREE.MeshStandardMaterial({ map: woodTex('#8a5a36', 8, [2.2, 3]), roughness: 0.75 }), 1.2);
    const wallM = new THREE.MeshStandardMaterial({ map: plasterTex, color: 0xb59c80, roughness: 0.95 }); wallM.bumpMap = plasterTex; wallM.bumpScale = 1.6;
    const panelM = relief(new THREE.MeshStandardMaterial({ map: woodTex('#4a2c1a', 6, [3, 1]), roughness: 0.9 }), 0.8);
    const deskWoodM = relief(new THREE.MeshStandardMaterial({ map: woodTex('#7a4a2a', 5, [1, 1]), roughness: 0.65 }), 0.6);
    const beigeM = new THREE.MeshStandardMaterial({ color: 0xd9ceb2, roughness: 0.55 });
    const beigeD = new THREE.MeshStandardMaterial({ color: 0xb9ad90, roughness: 0.6 });
    const darkM = new THREE.MeshStandardMaterial({ color: 0x1c1a18, roughness: 0.5 });
    const metalM = new THREE.MeshStandardMaterial({ color: 0x2f4a3c, roughness: 0.35, metalness: 0.6, side: THREE.DoubleSide });
    const frameM = new THREE.MeshStandardMaterial({ color: 0xe9e1d2, roughness: 0.5 });

    // piso, paredes e teto (parede esquerda com a janela)
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(6.6, 11.4), floorM); floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0.002, 3.3); floor.receiveShadow = true; set.add(floor);
    const backW = new THREE.Mesh(new THREE.PlaneGeometry(6.6, 4.5), wallM); backW.position.set(0, 2.25, -2.4); backW.receiveShadow = true; set.add(backW);
    box(6.6, 1.05, 0.04, panelM, 0, 0.525, -2.38); box(6.6, 0.05, 0.07, panelM, 0, 1.06, -2.37); box(6.6, 0.12, 0.05, panelM, 0, 0.06, -2.36);
    const rw = new THREE.Mesh(new THREE.PlaneGeometry(9.4, 4.5), wallM); rw.rotation.y = -Math.PI / 2; rw.position.set(3.3, 2.25, 2.3); rw.receiveShadow = true; set.add(rw);
    box(0.05, 0.12, 9.4, panelM, 3.27, 0.06, 2.3);
    const WX = -3.25, WZ0 = -1.9, WZ1 = 2.3, WY0 = 1.0, WY1 = 3.85, WZC = (WZ0 + WZ1) / 2, WZL = WZ1 - WZ0;
    box(0.12, 4.5, WZ0 + 2.4, wallM, WX, 2.25, (-2.4 + WZ0) / 2);
    box(0.12, 4.5, 7.0 - WZ1, wallM, WX, 2.25, (WZ1 + 7.0) / 2);
    box(0.12, WY0, WZL, wallM, WX, WY0 / 2, WZC);
    box(0.12, 4.5 - WY1, WZL, wallM, WX, (WY1 + 4.5) / 2, WZC);
    box(6.8, 0.12, 11.6, wallM, 0, 4.56, 3.3);
    // janela: moldura, peitoril, travessas e persiana
    box(0.32, 0.05, WZL + 0.3, frameM, WX + 0.12, WY0 - 0.02, WZC);
    box(0.14, 0.06, WZL + 0.12, frameM, WX, WY1 + 0.03, WZC);
    for (const z of [WZ0 - 0.03, WZ1 + 0.03, WZC]) box(0.14, WY1 - WY0, 0.06, frameM, WX, (WY0 + WY1) / 2, z);
    box(0.1, 0.045, WZL, frameM, WX, (WY0 + WY1) / 2 + 0.25, WZC);
    const slatM = new THREE.MeshStandardMaterial({ color: 0xefe6d4, roughness: 0.6, side: THREE.DoubleSide });
    cine.slats = [];
    const NSL = 28;
    for (let i = 0; i < NSL; i++) { const y = WY1 - 0.08 - i * ((WY1 - WY0 - 0.12) / (NSL - 1)); const s = box(0.115, 0.006, WZL - 0.04, slatM, WX + 0.13, y, WZC); s.rotation.z = -0.1; cine.slats.push(s); }
    box(0.1, 0.06, WZL, frameM, WX + 0.13, WY1 - 0.01, WZC);
    // ceu de fim de tarde la fora
    const skyTex = cvTex(64, 512, (x, w, h) => { const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#6f8fd0'); g.addColorStop(0.42, '#ffc98a'); g.addColorStop(0.58, '#ffe6b8'); g.addColorStop(0.72, '#ff9a5a'); g.addColorStop(1, '#4a3038'); x.fillStyle = g; x.fillRect(0, 0, w, h); });
    cine.sky = new THREE.Mesh(new THREE.PlaneGeometry(22, 10), new THREE.MeshBasicMaterial({ map: skyTex, toneMapped: false, fog: false })); cine.sky.material.color.setScalar(1.6);
    cine.sky.rotation.y = Math.PI / 2; cine.sky.position.set(-7.5, 2.2, -0.3); set.add(cine.sky);

    // mesa de madeira
    const DX = -0.55, DZ = -1.9, DY = 0.92;
    box(3.0, 0.06, 0.9, deskWoodM, DX, DY - 0.03, DZ);
    box(0.06, DY - 0.06, 0.84, deskWoodM, DX - 1.45, (DY - 0.06) / 2, DZ);
    box(0.6, DY - 0.06, 0.84, deskWoodM, DX + 1.17, (DY - 0.06) / 2, DZ);
    for (let i = 0; i < 3; i++) { box(0.54, 0.24, 0.02, deskWoodM, DX + 1.17, 0.16 + i * 0.27, DZ + 0.43); box(0.12, 0.02, 0.03, metalM, DX + 1.17, 0.2 + i * 0.27, DZ + 0.455); }
    box(2.3, 0.5, 0.02, deskWoodM, DX - 0.25, DY - 0.32, DZ - 0.38);

    // computador retro (bege) com a tela que mostra os cartoes do roteiro
    const crt = new THREE.Group(); crt.position.set(-1.25, DY, -1.95); crt.rotation.y = 0.32; set.add(crt);
    box(1.0, 0.2, 0.85, beigeM, 0, 0.1, 0.05, crt);
    box(0.36, 0.02, 0.01, darkM, -0.22, 0.13, 0.476, crt); box(0.36, 0.02, 0.01, darkM, -0.22, 0.07, 0.476, crt);
    box(0.025, 0.012, 0.01, new THREE.MeshBasicMaterial({ color: 0x5dff7a, toneMapped: false }), 0.38, 0.1, 0.476, crt);
    box(0.98, 0.84, 0.16, beigeM, 0, 0.62, 0.28, crt);
    box(0.78, 0.66, 0.55, beigeD, 0, 0.6, -0.06, crt);
    box(0.5, 0.45, 0.2, beigeD, 0, 0.58, -0.4, crt);
    for (const kx of [0.33, 0.4]) { const kn = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.02, 12), darkM); kn.rotation.x = Math.PI / 2; kn.position.set(kx, 0.27, 0.37); crt.add(kn); }
    const scrBorder = new THREE.Mesh(new THREE.PlaneGeometry(0.88, 0.64), new THREE.MeshStandardMaterial({ color: 0x0c0c0c, roughness: 0.3 })); scrBorder.position.set(0, 0.64, 0.3605); crt.add(scrBorder);
    cine.screen = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.56), tMat); cine.screen.position.set(0, 0.64, 0.362); crt.add(cine.screen);
    const scan = cvTex(8, 8, x => { x.clearRect(0, 0, 8, 8); x.fillStyle = 'rgba(0,0,0,.3)'; x.fillRect(0, 0, 8, 3); }, [1, 95]);
    const sc = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.56), new THREE.MeshBasicMaterial({ map: scan, transparent: true, toneMapped: false, depthWrite: false })); sc.position.set(0, 0.64, 0.3625); crt.add(sc);
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(0.84, 0.6), new THREE.MeshPhysicalMaterial({ color: 0x000000, roughness: 0.3, transparent: true, opacity: 0.07, envMapIntensity: 0.5 })); glass.position.set(0, 0.64, 0.364); /* sem vidro: reflexo lavava a tela */
    const note = box(0.12, 0.12, 0.003, new THREE.MeshStandardMaterial({ color: 0xf5d94a, roughness: 0.8 }), 0.4, 0.97, 0.3615, crt); note.rotation.z = 0.1;
    cine.scrL = new THREE.PointLight(0x9cc8ff, 1.0, 3, 2); cine.scrL.position.set(0, 0.64, 0.8); crt.add(cine.scrL);
    // teclado, mouse, caneca, disquetes, papeis, livros
    const kbG = new THREE.Group(); kbG.position.set(-0.98, DY, -1.47); kbG.rotation.y = 0.2; set.add(kbG);
    box(0.86, 0.035, 0.28, beigeM, 0, 0.0175, 0, kbG);
    const keys = new THREE.InstancedMesh(new RoundedBoxGeometry(0.044, 0.022, 0.044, 2, 0.006), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 }), 85); keys.castShadow = keys.receiveShadow = true;
    { const m4 = new THREE.Matrix4(), cK = new THREE.Color(); let ki = 0;
      for (let r = 0; r < 5; r++) for (let c = 0; c < 17; c++) { m4.makeTranslation(-0.39 + c * 0.049, 0.045 + r * 0.004, 0.1 - r * 0.049); keys.setMatrixAt(ki, m4); keys.setColorAt(ki, cK.setHex(c > 13 || r === 4 ? 0x9a9284 : 0xe6dcc4)); ki++; } }
    kbG.add(keys);
    box(0.26, 0.004, 0.22, new THREE.MeshStandardMaterial({ color: 0x23303a, roughness: 0.9 }), -0.32, DY + 0.002, -1.5);
    box(0.065, 0.03, 0.11, beigeM, -0.32, DY + 0.019, -1.5);
    const cer = new THREE.MeshStandardMaterial({ color: 0xc94c3a, roughness: 0.35 });
    const mug = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.046, 0.11, 24), cer); mug.position.set(0.18, DY + 0.055, -1.62); mug.castShadow = mug.receiveShadow = true; set.add(mug);
    const hdl = new THREE.Mesh(new THREE.TorusGeometry(0.03, 0.009, 8, 16), cer); hdl.position.set(0.235, DY + 0.06, -1.62); hdl.castShadow = true; set.add(hdl);
    [0x2d4a8a, 0x1e1e1e, 0xb83a2e].forEach((c, i) => { const f = box(0.1, 0.008, 0.1, new THREE.MeshStandardMaterial({ color: c, roughness: 0.4 }), -0.15, DY + 0.004 + i * 0.009, -1.82); f.rotation.y = (R() - 0.5) * 0.6; });
    [[0.38, -1.78, 0.2], [0.42, -1.74, -0.15]].forEach(([x, z, r]) => { const p = box(0.21, 0.002, 0.29, new THREE.MeshStandardMaterial({ color: 0xf1ece0, roughness: 0.9 }), x, DY + 0.002, z); p.rotation.y = r; });
    [[0x3a5a7a, 0.05], [0x8a3a2a, 0.04], [0xd8c8a0, 0.045]].forEach(([c, h], i) => { const b = box(0.3, h, 0.22, new THREE.MeshStandardMaterial({ color: c, roughness: 0.7 }), 0.72, DY + 0.03 + i * 0.047, -2.12); b.rotation.y = (R() - 0.5) * 0.3; });
    // abajur articulado
    const rod = (a, b, r, m) => { const d = b.clone().sub(a); const o = new THREE.Mesh(new THREE.CylinderGeometry(r, r, d.length(), 10), m); o.position.copy(a).addScaledVector(d, 0.5); o.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); o.castShadow = true; set.add(o); return o; };
    const LB = new THREE.Vector3(0.5, DY + 0.04, -2.12), LE = new THREE.Vector3(0.47, DY + 0.66, -2.02), LH = new THREE.Vector3(0.24, DY + 0.6, -1.78);
    const lbase = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.04, 24), metalM); lbase.position.set(LB.x, DY + 0.02, LB.z); lbase.castShadow = lbase.receiveShadow = true; set.add(lbase);
    rod(LB, LE, 0.013, metalM); rod(LE, LH, 0.013, metalM);
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.17, 24, 1, true), metalM); shade.position.copy(LH).add(new THREE.Vector3(0, -0.05, 0)); shade.rotation.z = 0.3; shade.castShadow = true; set.add(shade);
    cine.bulbM = new THREE.MeshBasicMaterial({ color: 0xffe0b0, toneMapped: false });
    const bulbP = LH.clone().add(new THREE.Vector3(-0.02, -0.11, 0)); const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.04, 16, 12), cine.bulbM); bulb.position.copy(bulbP); set.add(bulb);
    cine.lamp = new THREE.SpotLight(0xffc988, 2.5, 3.5, 0.8, 0.7, 2); cine.lamp.position.copy(bulbP).add(new THREE.Vector3(0, -0.03, 0)); cine.lamp.target.position.set(-0.1, DY, -1.62);
    cine.lamp.castShadow = true; cine.lamp.shadow.mapSize.set(1024, 1024); cine.lamp.shadow.bias = -0.0006; scene.add(cine.lamp, cine.lamp.target);
    // estante com livros
    const shelfM = new THREE.MeshStandardMaterial({ map: woodTex('#5a3620', 4, [1, 2]), roughness: 0.55 });
    const SX = 2.15, SZ = -2.18, SW = 1.15, SH = 2.5, SD = 0.38;
    box(0.04, SH, SD, shelfM, SX - SW / 2, SH / 2, SZ); box(0.04, SH, SD, shelfM, SX + SW / 2, SH / 2, SZ); box(SW, SH, 0.02, shelfM, SX, SH / 2, SZ - SD / 2);
    const shelfYs = [0.08, 0.6, 1.1, 1.6, 2.1, 2.49];
    shelfYs.forEach(y => box(SW, 0.035, SD, shelfM, SX, y, SZ));
    const bookCols = [0x7a2e22, 0x2c4a6e, 0xc9a24a, 0x3d5a3a, 0x8c6a4a, 0x5a2c4a, 0xd8cdb4, 0x1f2a36, 0xa8452e, 0x6b7a5a];
    for (let s = 0; s < 5; s++) {
      let x = SX - SW / 2 + 0.04; const y0 = shelfYs[s] + 0.0175, lim = SX + SW / 2 - 0.04 - (s % 2 ? 0.32 : 0.06);
      while (x < lim) { const w = 0.03 + R() * 0.045, h = 0.24 + R() * 0.17, d = 0.2 + R() * 0.1; if (x + w > lim) break;
        const b = box(w, h, d, new THREE.MeshStandardMaterial({ color: bookCols[(R() * bookCols.length) | 0], roughness: 0.7 }), x + w / 2, y0 + h / 2, SZ + 0.03);
        if (R() < 0.08) { b.rotation.z = 0.22; b.position.x += 0.04; x += 0.05; } x += w + 0.003; }
      if (s % 2) { const vase = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.2, 16), new THREE.MeshStandardMaterial({ color: 0x3c6e6a, roughness: 0.3 })); vase.position.set(lim + 0.16, y0 + 0.1, SZ); vase.castShadow = vase.receiveShadow = true; set.add(vase); }
    }
    // quadros na parede
    const posterTex = cvTex(600, 840, (x, w, h) => { const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#efe2c8'); g.addColorStop(0.6, '#f3d6a8'); g.addColorStop(1, '#e8b27a'); x.fillStyle = g; x.fillRect(0, 0, w, h);
      x.fillStyle = '#e0683e'; x.beginPath(); x.arc(w / 2, h * 0.52, w * 0.3, Math.PI, 0); x.fill();
      x.fillStyle = '#efe2c8'; for (let i = 0; i < 6; i++) x.fillRect(0, h * 0.4 + i * 22 + i * i * 2, w, 5 + i * 2);
      x.fillStyle = '#2f5a5c'; x.beginPath(); x.moveTo(0, h * 0.62); for (let i = 0; i <= 10; i++) x.lineTo(i * w / 10, h * (0.55 + 0.06 * Math.sin(i * 1.9))); x.lineTo(w, h); x.lineTo(0, h); x.fill();
      x.fillStyle = '#f6e8cf'; x.textAlign = 'center'; x.font = "900 66px Montserrat"; x.fillText('NIGHT DRIVE', w / 2, h * 0.86); x.font = "600 26px Montserrat"; x.fillText('— 1986 —', w / 2, h * 0.92); });
    box(0.78, 1.06, 0.03, new THREE.MeshStandardMaterial({ color: 0x6a4428, roughness: 0.5 }), -0.2, 2.62, -2.37);
    const poster = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.98), new THREE.MeshStandardMaterial({ map: posterTex, roughness: 0.7 })); poster.position.set(-0.2, 2.62, -2.353); poster.receiveShadow = true; set.add(poster);
    const photoTex = cvTex(300, 240, (x, w, h) => { const g = x.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#2c5a6a'); g.addColorStop(1, '#c9a46a'); x.fillStyle = g; x.fillRect(0, 0, w, h); x.fillStyle = 'rgba(20,30,30,.7)'; x.beginPath(); x.moveTo(0, h); x.lineTo(w * 0.35, h * 0.45); x.lineTo(w * 0.6, h * 0.7); x.lineTo(w * 0.8, h * 0.5); x.lineTo(w, h); x.fill(); });
    box(0.46, 0.38, 0.025, new THREE.MeshStandardMaterial({ color: 0x6a4428, roughness: 0.5 }), 0.75, 2.35, -2.37);
    const photo = new THREE.Mesh(new THREE.PlaneGeometry(0.38, 0.3), new THREE.MeshStandardMaterial({ map: photoTex, roughness: 0.6 })); photo.position.set(0.75, 2.35, -2.355); set.add(photo);
    // planta perto da janela
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.17, 0.42, 20), new THREE.MeshStandardMaterial({ color: 0xa8583a, roughness: 0.85 })); pot.position.set(-2.7, 0.21, -1.95); pot.castShadow = pot.receiveShadow = true; set.add(pot);
    const leafM = new THREE.MeshStandardMaterial({ color: 0x3f6e3a, roughness: 0.6, flatShading: true, side: THREE.DoubleSide });
    for (let i = 0; i < 20; i++) { const a = i * 2.39996, up = 0.45 + R() * 0.5; const dir = new THREE.Vector3(Math.cos(a) * (1 - up), up + 0.3, Math.sin(a) * (1 - up)).normalize();
      const lf = new THREE.Mesh(new THREE.SphereGeometry(1, 6, 4), leafM); lf.scale.set(0.075, 0.38 + R() * 0.2, 0.018); lf.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir); lf.rotateY(R() * 3);
      lf.position.set(-2.7, 0.42, -1.95).addScaledVector(dir, 0.3); lf.castShadow = lf.receiveShadow = true; set.add(lf); }
    // tapete
    const rugTex = cvTex(512, 384, (x, w, h) => { x.fillStyle = '#7a3a2c'; x.fillRect(0, 0, w, h); x.strokeStyle = '#e2cfa8'; x.lineWidth = 10; x.strokeRect(22, 22, w - 44, h - 44); x.strokeStyle = '#2d4b54'; x.lineWidth = 6; x.strokeRect(44, 44, w - 88, h - 88);
      for (let i = 0; i < 7; i++) { x.fillStyle = i % 2 ? '#c99a5a' : '#2d4b54'; x.beginPath(); const cx = 100 + i * 52; x.moveTo(cx, h / 2 - 40); x.lineTo(cx + 22, h / 2); x.lineTo(cx, h / 2 + 40); x.lineTo(cx - 22, h / 2); x.fill(); }
      for (let i = 0; i < 20000; i++) { x.fillStyle = `rgba(0,0,0,${R() * 0.12})`; x.fillRect(R() * w, R() * h, 2, 2); } });
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 2.0), new THREE.MeshStandardMaterial({ map: rugTex, roughness: 1 })); rug.rotation.x = -Math.PI / 2; rug.position.set(0.05, 0.006, 0.55); rug.receiveShadow = true; set.add(rug);

    // cortinas de tecido ao lado da janela
    const curtM = new THREE.MeshStandardMaterial({ color: 0xa8743e, roughness: 1, side: THREE.DoubleSide });
    for (const z0 of [WZ0 - 0.32, WZ1 + 0.32]) {
      const g = new THREE.PlaneGeometry(0.62, 3.3, 48, 1); const pa = g.attributes.position;
      for (let i = 0; i < pa.count; i++) { const u = pa.getX(i); pa.setZ(i, 0.045 * Math.sin(u * 38) + 0.02 * Math.sin(u * 91)); }
      g.computeVertexNormals(); const c = new THREE.Mesh(g, curtM); c.rotation.y = Math.PI / 2; c.position.set(WX + 0.2, 2.42, z0); c.castShadow = c.receiveShadow = true; set.add(c);
    }
    box(0.03, 0.03, WZL + 1.6, metalM, WX + 0.2, 4.1, WZC);
    // cadeira de escritorio
    const chair = new THREE.Group(); chair.position.set(1.15, 0, -1.15); chair.rotation.y = -0.7; set.add(chair);
    const fab = new THREE.MeshStandardMaterial({ color: 0x3a3330, roughness: 0.95 });
    box(0.5, 0.08, 0.48, fab, 0, 0.52, 0, chair); box(0.46, 0.55, 0.07, fab, 0, 0.88, -0.24, chair);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.4, 12), metalM); pole.position.y = 0.3; pole.castShadow = true; chair.add(pole);
    for (let i = 0; i < 5; i++) { const a = i * Math.PI * 2 / 5; const leg = box(0.32, 0.03, 0.04, darkM, Math.cos(a) * 0.16, 0.08, Math.sin(a) * 0.16, chair); leg.rotation.y = -a;
      const wh = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), darkM); wh.position.set(Math.cos(a) * 0.3, 0.03, Math.sin(a) * 0.3); wh.castShadow = true; chair.add(wh); }
    // caixinhas de som, porta-lapis, cacto
    for (const sx of [-2.0, -0.55]) { const sp = box(0.16, 0.24, 0.16, beigeD, sx, DY + 0.12, -2.05); sp.rotation.y = sx < -1 ? 0.3 : -0.2;
      const cone = new THREE.Mesh(new THREE.CircleGeometry(0.05, 20), darkM); cone.position.set(0, 0.03, 0.081); sp.add(cone); }
    const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.1, 18, 1, true), new THREE.MeshStandardMaterial({ color: 0x26323a, roughness: 0.4, side: THREE.DoubleSide })); cup.position.set(0.05, DY + 0.05, -2.08); cup.castShadow = true; set.add(cup);
    [0xe8c547, 0xd94a3a, 0x3a6ad9, 0x2a2a2a].forEach((c, i) => { const pn = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.18, 6), new THREE.MeshStandardMaterial({ color: c, roughness: 0.5 })); pn.position.set(0.05 + Math.cos(i * 1.6) * 0.015, DY + 0.11, -2.08 + Math.sin(i * 1.6) * 0.015); pn.rotation.set(Math.sin(i) * 0.25, 0, Math.cos(i) * 0.25); pn.castShadow = true; set.add(pn); });
    const cpot = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.035, 0.07, 16), new THREE.MeshStandardMaterial({ color: 0xc8b89a, roughness: 0.8 })); cpot.position.set(-1.88, DY + 0.035, -1.6); cpot.castShadow = true; set.add(cpot);
    const cac = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.07, 4, 8), new THREE.MeshStandardMaterial({ color: 0x4f7a45, roughness: 0.7, flatShading: true })); cac.position.set(-1.88, DY + 0.12, -1.6); cac.castShadow = true; set.add(cac);
    // cabos saindo do computador
    const cabM = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.6 });
    for (const [a, b, c] of [[[-1.35, DY + 0.3, -2.3], [-1.5, DY - 0.1, -2.36], [-1.6, 0.02, -2.3]], [[-1.15, DY + 0.1, -2.3], [-1.0, DY - 0.3, -2.37], [-0.8, 0.02, -2.32]]]) {
      const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(...a), new THREE.Vector3(...b), new THREE.Vector3(...c), new THREE.Vector3(c[0] + 0.4, 0.01, c[2] + 0.05)]), 40, 0.009, 6), cabM); tube.castShadow = true; set.add(tube); }
    // tomada e interruptor
    box(0.08, 0.12, 0.01, frameM, -0.95, 0.3, -2.355); box(0.08, 0.12, 0.01, frameM, 2.9, 1.25, -2.395);
    // prateleira na parede com objetos
    box(0.9, 0.03, 0.22, deskWoodM, 0.95, 1.85, -2.29);
    [[0x8a3a2a, 0.04, 0.18], [0x2c4a6e, 0.035, 0.2], [0xc9a24a, 0.05, 0.16]].forEach(([c, w, h], i) => box(w, h, 0.15, new THREE.MeshStandardMaterial({ color: c, roughness: 0.7 }), 0.6 + i * 0.05, 1.865 + h / 2, -2.29));
    const globe = new THREE.Mesh(new THREE.SphereGeometry(0.07, 20, 14), new THREE.MeshStandardMaterial({ color: 0x3d6e8a, roughness: 0.4 })); globe.position.set(1.15, 1.95, -2.29); globe.castShadow = true; set.add(globe);
    box(0.04, 0.02, 0.04, metalM, 1.15, 1.875, -2.29);

    // luzes: sol pela persiana, ceu azul de preenchimento, luz rebatida quente, contra frio, abajur e tela
    cine.sunDir = new THREE.Vector3(0.75, -0.5, -0.45).normalize();
    cine.sunT = new THREE.Vector3(-0.5, 1.3, -0.9);
    cine.sun = new THREE.DirectionalLight(0xffb06a, 7); cine.sun.castShadow = true;
    cine.sun.shadow.mapSize.set(4096, 4096); Object.assign(cine.sun.shadow.camera, { left: -5, right: 5, top: 5, bottom: -5, near: 1, far: 30 }); cine.sun.shadow.bias = -0.0002; cine.sun.shadow.normalBias = 0.025;
    cine.sun.target.position.copy(cine.sunT); scene.add(cine.sun, cine.sun.target);
    cine.hemi = new THREE.HemisphereLight(0x9fb4ff, 0x6a4630, 0.42); scene.add(cine.hemi);
    cine.bounce = new THREE.PointLight(0xff9a55, 2.5, 6, 2); cine.bounce.position.set(-0.5, 1.1, -0.9); scene.add(cine.bounce);
    RectAreaLightUniformsLib.init();
    cine.winL = new THREE.RectAreaLight(0xffd2a0, 2.2, WZL, WY1 - WY0); cine.winL.position.set(WX + 0.1, (WY0 + WY1) / 2, WZC); cine.winL.lookAt(0, (WY0 + WY1) / 2, WZC); scene.add(cine.winL);
    cine.cubeRT = new THREE.WebGLCubeRenderTarget(256, { type: THREE.HalfFloatType }); cine.cubeCam = new THREE.CubeCamera(0.05, 40, cine.cubeRT); cine.cubeCam.position.set(-0.2, 1.5, -0.3); scene.add(cine.cubeCam);
    cine.rimL = new THREE.DirectionalLight(0x86a0ff, 0.8); cine.rimL.position.set(4, 3.5, -3); scene.add(cine.rimL);
    cine.uglyHemi = new THREE.HemisphereLight(0xffffff, 0x808080, 2.4); cine.uglyHemi.visible = false; scene.add(cine.uglyHemi);
    cine.ugly = new THREE.MeshLambertMaterial({ color: 0x9c9c9c });

    // feixes de luz entre as laminas da persiana + poeira
    cine.shafts = new THREE.Group(); scene.add(cine.shafts);
    const shTex = cvTex(256, 4, (x, w, h) => { const g = x.createLinearGradient(0, 0, w, 0); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.45, 'rgba(255,255,255,.5)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, w, h); });
    shTex.colorSpace = THREE.NoColorSpace;
    const xA = cine.sunDir.clone(), zA = new THREE.Vector3(0, 0, 1).addScaledVector(xA, -xA.z).normalize(), yA = new THREE.Vector3().crossVectors(zA, xA);
    const qb = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(xA, yA, zA));
    const SL = 4.2; cine.shaftOp = 0.013; const gaps = [];
    for (let i = 0; i < NSL - 1; i++) {
      const y = (cine.slats[i].position.y + cine.slats[i + 1].position.y) / 2; gaps.push(y);
      const g = new THREE.BoxGeometry(SL, 0.04, WZL - 0.1); g.translate(SL / 2, 0, 0);
      const sh = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0xffc890, alphaMap: shTex, transparent: true, opacity: cine.shaftOp, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false }));
      sh.quaternion.copy(qb); sh.position.set(WX + 0.15, y, WZC); cine.shafts.add(sh);
    }
    { const N = 900, pos = new Float32Array(N * 3); cine.dustSeed = [];
      for (let i = 0; i < N; i++) { const p = new THREE.Vector3(WX + 0.15, gaps[(R() * gaps.length) | 0] + (R() - 0.5) * 0.06, WZ0 + 0.1 + R() * (WZL - 0.2)).addScaledVector(xA, R() * SL * 0.75); cine.dustSeed.push(p); pos.set([p.x, p.y, p.z], i * 3); }
      const dg = new THREE.BufferGeometry(); dg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      cine.dust = new THREE.Points(dg, new THREE.PointsMaterial({ color: 0xffe2b8, size: 2.2, sizeAttenuation: false, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, toneMapped: false })); scene.add(cine.dust); }

    // pos-processamento: AO e foco (sem os feixes, que nao tem superficie), acumulo de sub-quadros e cor de cinema
    class Hook extends Pass { constructor(fn) { super(); this.fn = fn; this.needsSwap = false; } render() { this.fn(); } }
    cine.gtao = new GTAOPass(scene, camera, 1080, 1920); cine.gtao.output = GTAOPass.OUTPUT.Default; cine.gtao.blendIntensity = 1.0;
    cine.gtao.updateGtaoMaterial({ radius: 0.45, distanceExponent: 1.5, thickness: 1.5, scale: 1.0, samples: 16 });
    cine.gtao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 5, rings: 2, samples: 16 });
    cine.bokeh = new BokehPass(scene, camera, { focus: 3, aperture: 0.002, maxblur: 0.006 });
    composer.insertPass(new Hook(() => { cine.fxVis = cine.shafts.visible; cine.haloVis = halo.visible; cine.shafts.visible = cine.dust.visible = halo.visible = false; }), 1);
    composer.insertPass(cine.gtao, 2); composer.insertPass(cine.bokeh, 3);
    composer.insertPass(new Hook(() => { cine.shafts.visible = cine.dust.visible = cine.fxVis; halo.visible = cine.haloVis; }), 4);
    composer.renderToScreen = false;
    const VS = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
    cine.acc = new THREE.WebGLRenderTarget(1080, 1920, { type: THREE.HalfFloatType });
    cine.accQ = new FullScreenQuad(new THREE.ShaderMaterial({ uniforms: { tDiffuse: { value: null }, w: { value: 0.1 } }, vertexShader: VS,
      fragmentShader: 'uniform sampler2D tDiffuse; uniform float w; varying vec2 vUv; void main(){ gl_FragColor = vec4(texture2D(tDiffuse, vUv).rgb * w, 1.0); }',
      blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false }));
    cine.gradeQ = new FullScreenQuad(new THREE.ShaderMaterial({ uniforms: { tDiffuse: { value: null }, time: { value: 0 }, amount: { value: 1 } }, vertexShader: VS, depthTest: false, depthWrite: false,
      fragmentShader: `uniform sampler2D tDiffuse; uniform float time; uniform float amount; varying vec2 vUv;
        float rnd(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
        void main(){
          vec2 d = vUv - 0.5; float r = dot(d, d);
          vec2 off = d * 0.0035 * amount;
          vec3 c = vec3(texture2D(tDiffuse, vUv + off).r, texture2D(tDiffuse, vUv).g, texture2D(tDiffuse, vUv - off).b);
          float l = dot(c, vec3(0.299, 0.587, 0.114));
          c += amount * (vec3(-0.012, 0.008, 0.03) * (1.0 - l) + vec3(0.035, 0.012, -0.025) * l);
          c = mix(c, c * c * (3.0 - 2.0 * c), 0.18 * amount);
          c = c * (1.0 - 0.03 * amount) + 0.025 * amount;
          c *= 1.0 - amount * r * 0.8;
          c += amount * (rnd(vUv * vec2(1080.0, 1920.0) + fract(time * 7.13) * 91.7) - 0.5) * 0.045;
          gl_FragColor = vec4(c, 1.0);
        }` }));

    // planos novos (clipador em x -0.4 z 0.3, Claude em x 0.55 z -0.1)
    set.updateMatrixWorld(true);
    const S = new THREE.Vector3(); cine.screen.getWorldPosition(S); const n = new THREE.Vector3(0, 0, 1).applyQuaternion(crt.quaternion);
    const atScr = (k, dy) => S.clone().addScaledVector(n, k).add(new THREE.Vector3(0, dy, 0)).toArray();
    Object.assign(SHOTS, {
      EST: { p: [0.9, 2.5, 7.6], q: [-0.7, 1.6, -1.5], d: [-0.4, -0.25, -1.6], ease: true, fov: 50 },
      CH: { p: [0.3, 1.8, 3.8], q: [-0.4, 1.68, 0.3], d: [-0.1, 0, -0.3] },
      LOWH: { p: [0.1, 0.95, 3.3], q: [-0.42, 1.78, 0.3], d: [0.12, 0.05, -0.1] },
      CC: { p: [1.4, 2.2, 4.4], q: [0.55, 2.0, -0.1], d: [-0.08, 0, -0.25] },
      SCR: { p: atScr(3.0, 0.06), q: S.toArray(), d: n.clone().multiplyScalar(-0.45).toArray(), scr: true },
      SCRE: { p: atScr(3.4, 0.1), q: S.toArray(), d: n.clone().multiplyScalar(-1.0).toArray(), scr: true, ease: true },
      UG: { p: [0, 1.85, 5.7], q: [0, 1.55, -0.3], d: [0, 0, 0], still: true },
      UGH: { p: [-0.1, 1.75, 3.7], q: [-0.4, 1.62, 0.3], d: [0, 0, 0], still: true },
      UGC: { p: [0.8, 2.05, 3.2], q: [0.55, 2.0, -0.1], d: [0, 0, 0], still: true },
      REV: { p: [0.3, 1.8, 6.4], q: [-0.3, 1.75, -1.0], d: [-0.2, 0.15, -1.6], ease: true, fov: 44 },
      OTS: { p: [3.0, 2.0, 2.9], q: [0, 1.85, 0], d: [-0.25, 0, -0.3] },
      ORB: { orbit: [0.05, 1.85, 0.1, 4.5, 0.4, -0.15, 1.95], q: [0.05, 1.8, 0.1] },
      ORB2: { orbit: [0.05, 1.85, 0.1, 4.0, 0.6, -0.7, 2.2], q: [0.05, 1.85, 0.1] },
      W2: { p: [0.2, 2.1, 6.3], q: [-0.3, 1.8, -0.8], d: [0, 0, -0.6], fov: 42 },
      MOUTH: { p: [0.25, 1.62, 2.25], q: [-0.38, 1.55, 0.35], d: [0, 0, -0.1] },
    });
  }

  function frameBlender(t, env, shot) {
    const P = actor('h', t); P.x = -0.4; P.z = 0.3;
    for (const [a, b, k] of (V.acoes || [])) {
      const w = win(t, a, b, 0.2); if (w < 0.001) continue;
      if (k === 'acena') { P.aRz += 2.35 * w; P.aRx -= 0.3 * w; P.hy += 0.25 * w; P.mouth += 0.6 * w; P.hop += 0.04 * w * Math.abs(Math.sin(t * 9)); }
      if (k === 'orgulho') { P.hp -= 0.12 * w; P.mouth += 0.3 * w; }
      if (k === 'olhaClaude') { P.hy += 0.4 * w; P.mouth += 0.4 * w; }
      if (k === 'olhaCamera') { P.hy -= 0.2 * w; }
      if (k === 'pula') P.hop += 0.08 * w * Math.abs(Math.sin(t * 8));
      if (k === 'comemora') { P.aLz -= 2.4 * w; P.aRz += 2.3 * w; P.hop += 0.09 * w * Math.abs(Math.sin(t * 9)); P.mouth += 0.5 * w; }
      if (k === 'triste') { P.hp += 0.3 * w; P.mouth -= 1.5 * w; P.browT += 0.22 * w; P.lean += 0.1 * w; }
      if (k === 'pensa') { P.aLx -= 2.3 * w; P.aLz += 0.35 * w; P.hr += 0.08 * w; }
    }
    if (talking('h', t) && env > 0.1) P.open = Math.max(P.open, Math.min(1, 0.08 + env * 1.15));
    poseKid(hero, P, t, 0.3);
    friend.g.visible = false;
    const CL = V.claude || {};
    const shy = winMax(t, CL.timido), laugh = winMax(t, CL.risada, 0.15), jump = winMax(t, CL.pula, 0.15);
    let spin = 0; for (const g of (CL.giros || [])) spin += smooth(g, g + 0.8, t) * Math.PI * 2;
    botAt(t, env, 0.55, 2.0 + 0.06 * laugh * Math.abs(Math.sin(t * 22)) + 0.12 * jump * Math.abs(Math.sin(t * 9)), -0.1, botLook(t) * 0.8 + spin - 0.35 * shy, 0.28 * shy + 0.05);
    if (shy > 0.01) { bot.eyeL.scale.y *= 1 - 0.75 * shy; bot.eyeR.scale.y *= 1 - 0.75 * shy; }
    halo.material.opacity *= 0.45;
    hero.g.visible = bot.g.visible = !shot.scr;
  }

  function cineLights(t, env, shot) {
    const ug = t >= V.ugly[0] && t < V.ugly[1];
    let flick = 1; for (const a of ((V.textos || {}).apagao || [])) if (t > a - 0.26 && t < a + 0.34) flick *= t < a ? 0.12 + 0.1 * Math.sin(t * 90) : smooth(a, a + 0.14, t);   // luzes piscam
    cine.oldLights.forEach(l => (l.intensity = 0));
    const ang = cine.sub * 2.39996, rr = Math.sqrt((cine.sub + 0.5) / cine.NS) * 0.03;          // sol "de area": sombras suaves
    tmpV.copy(cine.sunDir); tmpV.y += Math.cos(ang) * rr; tmpV.z += Math.sin(ang) * rr; tmpV.normalize();
    cine.sun.position.copy(cine.sunT).addScaledVector(tmpV, -14);
    cine.sun.intensity = ug ? 0 : 9 * flick;
    cine.hemi.intensity = ug ? 0 : 0.06 * (0.4 + 0.6 * flick);
    cine.bounce.intensity = ug ? 0 : 1.2 * flick;
    cine.rimL.intensity = ug ? 0 : 0.6 * flick; cine.winL.intensity = ug ? 0 : 2.2 * flick;
    cine.lamp.intensity = ug ? 0 : 2.5 * flick; cine.bulbM.color.setHex(0xffe0b0).multiplyScalar(ug ? 0.3 : 1.6 * flick);
    cine.scrL.intensity = ug ? 0 : 1.0;
    cine.uglyHemi.visible = ug;
    cine.shafts.visible = cine.dust.visible = !ug;
    cine.shafts.children.forEach((m, i) => (m.material.opacity = cine.shaftOp * flick * (0.75 + 0.25 * Math.sin(t * 0.6 + i * 0.9))));
    const dp = cine.dust.geometry.attributes.position; cine.dustSeed.forEach((pp, i) => dp.setXYZ(i, pp.x + 0.06 * Math.sin(t * 0.3 + i), pp.y + 0.03 * Math.sin(t * 0.23 + i * 1.7), pp.z + 0.06 * Math.cos(t * 0.27 + i * 0.7))); dp.needsUpdate = true;
    scene.overrideMaterial = ug ? cine.ugly : null; cine.gtao.enabled = cine.bokeh.enabled = !ug;
    scene.fog = ug ? null : cine.fog; scene.background = ug ? cine.uglyBg : cine.bg;
    halo.visible = !ug && !shot.scr; bot.rings.forEach(r => (r.visible = !ug));
    if (ug) bot.inner.intensity = 0;
    cine.bokeh.uniforms.focus.value = shot.focus;
    cine.bokeh.uniforms.aperture.value = shot.name === 'MOUTH' ? 0.005 : shot.name === 'EST' || shot.name.startsWith('ORB') || shot.name === 'W2' || shot.name === 'REV' ? 0.0013 : shot.scr ? 0.0022 : 0.003;
    bloom.strength = ug ? 0 : 0.3 + 0.05 * env; bloom.threshold = 0.8;
  }

  const TX = V.textos || {};
  if (CINE) {
    const tt = ovl('ttl'); tt.firstElementChild.textContent = TX.titulo ? TX.titulo.texto : '';
    const cm = ovl('cmts'); cm.innerHTML = '';
    ((TX.comentarios || {}).itens || []).forEach((c, i) => { const d = document.createElement('div'); d.textContent = c; d.dataset.r = String([-4, 3, 2, -3, -2, 4][i % 6]);
      d.style.top = (330 + i * 175) + 'px'; d.style[i % 2 ? 'right' : 'left'] = (60 + (i * 37) % 60) + 'px'; cm.appendChild(d); });
  }
  function cineOverlays(t) {
    const ti = TX.titulo;
    if (ti) { ovl('ttl').style.opacity = smooth(ti.t0, ti.t0 + 0.3, t) * (1 - smooth(ti.t1 - 0.3, ti.t1, t)); ovl('ttl').style.transform = `scale(${1.08 - 0.08 * smooth(ti.t0, ti.t1, t)})`; ovl('ttl').classList.toggle('x', ti.riscar != null && t > ti.riscar); }
    else ovl('ttl').style.opacity = 0;
    const co = TX.comentarios;
    if (co) { ovl('cmts').style.opacity = smooth(co.t0, co.t0 + 0.25, t) * (1 - smooth(co.t1 - 0.3, co.t1, t));
      [...ovl('cmts').children].forEach((c, i) => { const k = smooth(co.t0 + 0.05 + i * 0.32, co.t0 + 0.3 + i * 0.32, t); c.style.opacity = k; c.style.transform = `translateY(${(1 - k) * 40}px) rotate(${c.dataset.r}deg)`; }); }
    else ovl('cmts').style.opacity = 0;
    let tag = null; for (const e of (TX.etiquetas || [])) if (t >= e[0] && t < e[1]) tag = e;
    ovl('tag').style.opacity = tag ? Math.min(1, (t - tag[0]) / 0.18) * (1 - smooth(tag[1] - 0.35, tag[1], t)) : 0;
    if (tag) { ovl('tag').textContent = tag[2]; ovl('tag').className = tag[3] === 'ruim' ? 'bad' : 'good'; }
    let fl = 0; for (const f of (TX.flashes || [])) if (t >= f) fl = Math.max(fl, 1 - smooth(f, f + 0.38, t));
    ovl('flash').style.opacity = fl;
  }

  const fadeEl = document.getElementById('fade'), discEl = document.getElementById('disc');
  function stepScene(t) {
    const env = envAt(t), shot = cam(t);
    const work = PLANO ? (framePlano(t, env, shot), 0) : BLENDER ? (frameBlender(t, env, shot), 0) : frameFesta(t, env, shot);
    drawTelao(t); if (!CINE) drawMinis(t);
    // luzes: neon pulsando no tempo da musica (100 bpm)
    const beat = 0.78 + 0.22 * Math.exp(-((t % 0.6) * 5)), dim = 1 - 0.65 * work;
    lightL.intensity = 6 * beat * dim; lightR.intensity = 5 * beat * dim; lightT.intensity = (2.6 + 0.4 * Math.sin(t * 2.3)) * (1 - 0.3 * work);
    neonL.color.setHex(0xff3fa4).multiplyScalar(beat * dim); neonR.color.setHex(0x4fd8ff).multiplyScalar(beat * dim); ledM.color.setHex(0x9a6cff).multiplyScalar((0.7 + 0.3 * Math.sin(t * 1.4)) * dim);
    fans.forEach((f, i) => (f.rotation.z = t * (4 + i)));
    const car = shot.name === 'CAR';
    key.color.setHex(0xe8e0ff); key.intensity = car ? 0.9 : 0.55 * dim; key.position.set(car ? CARX - 3.5 : -3.5, 5.5, 6.5); key.target.position.set(car ? CARX : 0, 1.2, 0);
    spot.position.set(car ? CARX : 0.2, 6.5, 4.6); spot.target.position.set(car ? CARX : 0, 1.3, 0); spot.intensity = car ? 30 : 15 * dim; spot.angle = car ? 0.5 : 0.4;
    panelLight.intensity = 0; edgeLight.intensity = car ? 3.5 : 0; edgeLight.position.set(car ? CARX : 0, 0.25, 1.9);
    rim.intensity = car ? 3 : 1.2; rim2.intensity = car ? 1.9 : 0.8;
    cityMats.forEach(m => m.color.setScalar(1.0));
    bloom.strength = 0.42 + 0.06 * env;
    if (CINE) cineLights(t, env, shot);
    return { shot, car };
  }
  function cineRender(t) {
    const NS = cine.NS;
    const bounds = CUTS.map(c => c[0]).concat(V.ugly).sort((a, b) => a - b);      // o motion blur nao atravessa cortes
    let a = 0, b = DUR + 1; for (const x of bounds) { if (x <= t) a = x; else { b = x; break; } }
    if (!cine.envDone) {           // iluminacao global aproximada: captura o quarto iluminado e usa como luz ambiente e reflexos
      stepScene(3.0); const vis = [hero.g.visible, bot.g.visible, halo.visible]; hero.g.visible = bot.g.visible = halo.visible = false; cine.shafts.visible = cine.dust.visible = false;
      cine.cubeCam.update(renderer, scene);
      scene.environment = new THREE.PMREMGenerator(renderer).fromCubemap(cine.cubeRT.texture).texture; scene.environmentIntensity = 0.6;
      [hero.g.visible, bot.g.visible, halo.visible] = vis; cine.envDone = true;
    }
    renderer.setRenderTarget(cine.acc); renderer.setClearColor(0x000000, 1); renderer.clear();
    let st;
    for (let s = 0; s < NS; s++) {
      const ts = clamp(t + ((s + 0.5) / NS - 0.5) * cine.shutter, a, b - 1e-4);
      cine.sub = s; st = stepScene(ts);
      camera.setViewOffset(1080, 1920, ((s * 7) % NS + 0.5) / NS - 0.5, ((s * 3) % NS + 0.5) / NS - 0.5, 1080, 1920);
      composer.render();
      camera.clearViewOffset();
      cine.accQ.material.uniforms.tDiffuse.value = composer.readBuffer.texture; cine.accQ.material.uniforms.w.value = 1 / NS;
      renderer.setRenderTarget(cine.acc); renderer.autoClear = false; cine.accQ.render(renderer); renderer.autoClear = true;
    }
    renderer.setRenderTarget(null);
    const u = cine.gradeQ.material.uniforms; u.tDiffuse.value = cine.acc.texture; u.time.value = t; u.amount.value = t >= V.ugly[0] && t < V.ugly[1] ? 0 : 1;
    cine.gradeQ.render(renderer);
    return st;
  }
  window.renderFrame = (t) => {
    let st;
    if (CINE) { st = cineRender(t); cineOverlays(t); }
    else { st = stepScene(t); composer.render(); }
    fadeEl.style.opacity = Math.max(1 - smooth(0, 0.3, t), smooth(DUR - 0.9, DUR - 0.15, t));
    discEl.style.opacity = st.car ? 1 : 0;
    let html = '', who = 'h';
    for (const ln of LN) if (t >= ln[0] && t < ln[1] + 0.1) { html = ln[3]; who = ln[2]; }
    subEl.className = who === 'h' ? '' : who;
    if (subEl.dataset.h !== html) { subEl.innerHTML = html; subEl.dataset.h = html; }
    return true;
  };
}
